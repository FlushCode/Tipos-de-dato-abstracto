# -*- coding: utf-8 -*-
from PriorityQueue import * #clase del modulo PriorityQueue con el metodo añadido para ver primero
import sys

def obtener_mejores(base_de_datos, limite, cantidad_total_datos):
    '''Se obtienen los <limite> mejores elementos en la base de datos,
       <base de datos> es un diccionario clave:valor cuyos elementos
        son todos comparables, <cantidad_total_datos> es la cantidad de
        elementos en <base de datos>'''

    datos = [dato for dato in base_de_datos] #red_articulos = base_de_datos
    posicion_actual = 0
    top_datos = ColaPrioridad()
    for x in range(0,limite): #Encolo <cantidad> de articulos al principio, si no podria estar ignorando soluciones

        top_datos.put((base_de_datos[datos[x]], datos[x]))
        posicion_actual+=1
    
    for i in range(posicion_actual, cantidad_total_datos): #self.cantidad_art = maxelem

        dato_actual = datos[i]
        valor_actual = base_de_datos[dato_actual]
        ultimo_mejor = top_datos.first()
        valor_ultimo_mejor = ultimo_mejor[0]
                        
        if valor_actual > valor_ultimo_mejor:

            top_datos.get()
            top_datos.put((valor_actual,dato_actual))
    
    return top_datos

def mostrar_tabla(top_elementos, invertida = False):
    '''Muestra en forma de tabla a los elementos de <top_elementos>,
       <top_elementos> es una cola de prioridad, luego de la ejecucion
       de esta funcion quedará vacía, si se desea imprimir en el ordne 
       inverso, se puede pasar como parametro extra'''

    tabla = list()
    while not top_elementos.empty():

        articulo = top_elementos.get()
        tabla.append(articulo)
    
    if invertida:
        tabla.reverse()

    valor_elemento = 0
    nombre_elemento = 1
    sys.stdout.write("\n")
    for i in range(len(tabla)):
             
        print "{}. {}: {}".format(i + 1, tabla[i]
                  [nombre_elemento], tabla[i][valor_elemento]) 

