# -*- coding: utf-8 -*-
from grafo import *
from print_test import *
#algoritmo de pagerank, modificando la formula sin el detalle de dividir
#por la cantidad de articulos que se menciona en el enunciado del tp,
#esto es solo para adaptar el algoritmo a los ejemplos de la pagina
#http://www.cs.princeton.edu/~chazelle/courses/BIB/pagerank.htm

COEFICIENTE_AMORTIGUACION = 0.85
PAGERANK_DEFAULT = 1.85

def calcular_pagerank(iteraciones, red_articulos):
  
    '''Realiza K iteraciones del cálculo del pagerank. K un numero que se 
    le pedira al usuario
    '''

    while iteraciones > 0:

        for articulo in red_articulos:
        
            links = red_articulos.incidencias(articulo)               
            sumatoria = 0            
            for link in links:

                pagerank_link = red_articulos[link]
                relacionados_a_link = len(red_articulos.adyacentes(link))
                relacion_actual = pagerank_link/float(relacionados_a_link)
                sumatoria += relacion_actual    

            pagerank_articulo = (1 - COEFICIENTE_AMORTIGUACION) + (COEFICIENTE_AMORTIGUACION * sumatoria)
            red_articulos[articulo] = pagerank_articulo

        iteraciones -= 1

def agregar_articulos_red(articulos, red):
    '''Agrega los elementos de 'articulos' en 'red'''

    for articulo in articulos:

        red[articulo] = PAGERANK_DEFAULT

def linkear_red(links, red):
    ''''links' es un diccionario que contiene las conexiones a hacer entre
        todos los articulos de una red, red es una red implementada en un grafo
        Se agregan todas las aristas necesarias para que se encuentren todos los
        links del diccionario links'''

    for link in links:

        conexiones_link = links[link]
        for conexion in conexiones_link:
            
            red.agregar_arista(link, conexion)

def verificar_red(red, datos):
    '''Verifica que los articulos de la red contengan como datos
       los datos del diccionario 'datos' y se imprime un mensaje
       apropiado'''

    errores = 0
    for link in red:

        if abs(red[link] - datos[link]) > 0.1: #Margen de error

            errores += 1 

    return errores

def pruebas_red_1():

    red = Grafo(True)
    articulos = ["Pagina A","Pagina B","Pagina C","Pagina D"]
    links = {"Pagina A":["Pagina B","Pagina C"],"Pagina B":["Pagina C"],"Pagina C":["Pagina A"],"Pagina D":["Pagina C"]}

    agregar_articulos_red(articulos, red)
    linkear_red(links, red)    
    calcular_pagerank(80,red)
    datos = {"Pagina A": 1.49, "Pagina B": 0.78, "Pagina C": 1.58, "Pagina D": 0.15}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 1 correctos", errores == 0)

def pruebas_red_2():

    red = Grafo(True)
    articulos = ["Home","About","Product","Links","External Site A","External Site B","External Site C","External Site D"]
    agregar_articulos_red(articulos, red)
    links = {"Home":["About","Product","Links"],"About":["Home"],"Product":["Home"],"Links":["Home","External Site A","External Site B","External Site C","External Site D"]}
    linkear_red(links, red)
    calcular_pagerank(100,red)
    datos = {"Home":0.92, "About": 0.41, "Product":0.41, "Links": 0.41, "External Site A": 0.22, "External Site B": 0.22, "External Site C": 0.22, "External Site D": 0.22}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 2 correctos", errores == 0)

def pruebas_red_3():

    red = Grafo(True)
    articulos = ["Home","About","Product","Links","External Site A","External Site B","External Site C","External Site D"]
    agregar_articulos_red(articulos, red)
    links = {"Home":["About","Product","Links"],"About":["Home"],"Product":["Home"],"Links":["Home","External Site A","External Site B","External Site C","External Site D"],"External Site A":["Home"],"External Site B":["Home"],"External Site C":["Home"],"External Site D":["Home"]}
    linkear_red(links, red)
    calcular_pagerank(100,red)
    datos = {"Home":3.35, "About": 1.1, "Product":1.1, "Links": 1.1, "External Site A": 0.34, "External Site B": 0.34, "External Site C": 0.34, "External Site D":0.34}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 3 correctos", errores == 0)

def pruebas_red_4():

    red = Grafo(True)
    articulos = ["Home","About","Product","Links","External Site A","External Site B","External Site C","External Site D","Review A","Review B","Review C","Review D"]
    agregar_articulos_red(articulos, red)
    links = {"Home":["About","Product","Links"],"About":["Home"],"Product":["Home"],"Links":["Home","External Site A","External Site B","External Site C","External Site D","Review A","Review B","Review C","Review D"], "Review B":["Home"],"Review C":["Home"],"Review D":["Home"], "Review A": ["Home"]}
    linkear_red(links, red)
    calcular_pagerank(100,red)
    datos = {"Home":2.44, "About": 0.84, "Product":0.84, "Links": 0.84, "External Site A": 0.23, "External Site B": 0.23, "External Site C": 0.23, "External Site D": 0.23, "Review A": 0.23, "Review B": 0.23, "Review C": 0.23, "Review D": 0.23}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 4 correctos", errores == 0)

def pruebas_red_5():

    red = Grafo(True)
    articulos = ["Home","About","Product","Links"]
    agregar_articulos_red(articulos, red)
    links = {"Home":["About","Product","Links"],"About":["Home"],"Product":["Home"],"Links":["Home"]}
    linkear_red(links, red)
    calcular_pagerank(100,red)
    datos = {"Home":1.92, "About": 0.69, "Product":0.69, "Links": 0.69}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 5 correctos", errores == 0)

def pruebas_red_6():

    red = Grafo(True)
    articulos = ["Home","About","Product","More"]
    agregar_articulos_red(articulos, red)
    links = {"Home":["About"],"About":["Product"],"Product":["More"],"More":["Home"]}
    linkear_red(links, red)
    calcular_pagerank(100,red)
    datos = {"Home": 1, "About": 1, "Product":1, "More": 1}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 6 correctos", errores == 0)
    
def pruebas_red_7():

    red = Grafo(True)
    articulos = ["Home","About","Product","More"]
    agregar_articulos_red(articulos, red)
    links = {"Home":["About","Product","More"],"About":["Product","Home","More"],"Product":["More","Home","About"],"More":["Home","About","Product"]}
    linkear_red(links, red)
    calcular_pagerank(100,red)
    datos = {"Home": 1, "About": 1, "Product":1, "More": 1}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 7 correctos", errores == 0)
  
def pruebas_red_8():

    
    red = Grafo(True)
    articulos = ["Site A","Site B","Home","About","Product","Links"]
    agregar_articulos_red(articulos, red)
    links = {"Home":["About","Product","Links"],"About":["Home"],"Product":["Home","Site B"],"Links":["Home"],"Site A":["Home"]}
    linkear_red(links, red)
    calcular_pagerank(100,red)
    datos = {"Home":1.49,"About":0.57, "Product":0.57, "Links": 0.57, "Site B": 0.39, "Site A": 0.15}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 8 correctos", errores == 0)

def pruebas_red_11():

    red = Grafo(True)
    articulos = ["Page A","Page B","Page C","Page D"]
    agregar_articulos_red(articulos, red)
    links = {"Page A":["Page B"],"Page B":["Page A","Page C"],"Page C":["Page A","Page D"],"Page D":["Page A"]}
    linkear_red(links, red)
    calcular_pagerank(100,red)
    datos = {"Page A": 1.44, "Page B": 1.37, "Page C":0.73, "Page D":0.46}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 11 correctos", errores == 0)

def pruebas_red_12():

    red = Grafo(True)
    articulos = ["Page A","Page B","Page C","Page D"]
    agregar_articulos_red(articulos, red)
    links = {"Page A":["Page B"],"Page B":["Page A","Page C"],"Page C":["Page A","Page B","Page D"],"Page D":["Page A","Page C"]}
    linkear_red(links, red)
    calcular_pagerank(100,red)
    datos = {"Page A": 1.20, "Page B": 1.44, "Page C":0.94, "Page D":0.41}
    errores = verificar_red(red, datos)
    print_test("Pageranks red 12 correctos", errores == 0)

def pruebas_red_13():

    red = Grafo(True)
    principal = "Page A"
    soporte = "Page B"
    red[principal] = PAGERANK_DEFAULT
    red[soporte] = PAGERANK_DEFAULT
    red.agregar_arista(principal,soporte)
    for i in range(0,1000):

        spam = str(i)
        red[spam] = PAGERANK_DEFAULT
        red.agregar_arista(soporte, spam)
        red.agregar_arista(spam,principal)

    calcular_pagerank(100, red)
    print_test("Pagina principal PR",abs(red[principal] - 331) < 0.1)
    print_test("Pagina soporte PR",abs(red[soporte] - 281.6) < 0.1)

def main():
    pruebas_red_1()
    pruebas_red_2()
    pruebas_red_3()
    pruebas_red_4()
    pruebas_red_5()
    pruebas_red_6()
    pruebas_red_7()
    pruebas_red_8()
    pruebas_red_11()
    pruebas_red_12()
    pruebas_red_13()
main()
