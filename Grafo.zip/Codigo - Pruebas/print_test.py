
def print_test(msg, bool_expression):
    '''Si <bool_expression> es verdadera, imprimir el mensaje + '... OK',
     si no, imprime el mensaje + '... ERROR'
    '''

    if bool_expression == True:

        print msg+"... OK"
        return

    print msg+"... ERROR"

