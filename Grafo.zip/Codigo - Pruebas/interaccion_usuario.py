# -*- coding: utf-8 -*-
MSG_ERROR = "**El identificador ingresado no se encontro en la base de datos, por favor reintentar o ingresar -1 para cancelar**"
SALIR = "-1"
def pedir_natural(msg):
    '''Pide al usuario que ingrese un numero natural (incluido el 0)'''

    correcto = False
    while not correcto:

        n = raw_input(msg)
        if n.isdigit():

            correcto = True

    return int(n)

def pedir_vertice(grafo, mensaje):
    '''Pide al usuario que ingrese un identificador de vertice, si el usuario
       consulta por un vertice que no pertenece al grafo, se le consulta hasta
       que ingrese un vertice valido o -1 para finalizar la ejecucion (se devolverá
       -1 de todas maneras, o el articulo válido

        PRE: Los vertices del grafo son strings'''

    continuar = True
    
    while continuar:

        vertice = raw_input(mensaje)
        if vertice in grafo or vertice == SALIR:

            continuar = False
            continue

        print MSG_ERROR

    return vertice


