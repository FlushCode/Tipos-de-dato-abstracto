CANCELAR = '-1'
ERROR_APERTURA_ARCHIVO = "Archivo/directorio inexistente o no se tienen permisos, intente nuevamente"

def abrir_archivo(msg):
    '''Le pide al usuario que ingrese la ruta de un archivo y lo devuelve abierto,
       si la entrada es invalida se sigue preguntando hasta que se ingrese algo
       valido o ingrese '-1' para cancelar'''

    entrada_correcta = False
    while not entrada_correcta:
        try:
            nombre_archivo = raw_input(msg)
            if nombre_archivo == CANCELAR:

                return CANCELAR

            archivo = open(nombre_archivo,"r")
            entrada_correcta = True
        except IOError:
            print ERROR_APERTURA_ARCHIVO

    return archivo


def saltar_lineas(archivo, n):

    '''Avanza en el archivo hasta la linea n'''
    i = 0
    while i < n:

        archivo.readline()
        i += 1
