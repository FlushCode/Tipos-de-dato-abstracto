from grafo import *
from interaccion_usuario import *
from arch_utils import saltar_lineas

RANKING_DEFAULT = 0.23

def cargar_articulos(archivo,cantidad_articulos):
    '''Carga <cantidad_articulos> en un nuevo grafo, <archivo>
    es un archivo que debe tener el formato de un archivo parseado
    especialmente por el programa wikiparser.py. Devuelve el nuevo 
    grafo.
    '''

    grafo = Grafo(True)
    n = pedir_natural("Desde donde desea que se comience a leer el archivo?: ")
    saltar_lineas(archivo, n)
    i = 0
    while i < cantidad_articulos:

        linea = archivo.readline()
        articulo = linea.split(">")[0]
        grafo[articulo] = RANKING_DEFAULT 
        i += 1
        
    archivo.seek(0)
    return grafo, n

def relacionar_articulos(archivo, grafo, cantidad_articulos, inicio):
    '''Relaciona <cantidad_articulos> articulos ya cargados en el grafo   
       <archivo> debe ser el mismo archivo que se utilizo al cargar los
       articulos, o aunque sea tener los mismos Titulos de Articulos en
       las primeras <cantidad_articulos> lineas.
       Se actualiza el grafo.
    '''     
    
    j = 0
    saltar_lineas(archivo, inicio)
    while j < cantidad_articulos:

        linea = archivo.readline().rstrip("\n")
        informacion = linea.split(">")
        if len(informacion) > 1:
            articulo_principal = informacion[0]
            relaciones = informacion[1].split("<")
            for articulo in relaciones:
            
                if articulo in grafo:
                
                    grafo.agregar_arista(articulo_principal,articulo)

        j += 1

def cargar_grafo(archivo, limite):

    ''''Carga en un grafo hasta <limite> lineas de informacion del
        archivo, se devuelve un grafo con la informacion ya procesada'''

    grafo, saltos_linea = cargar_articulos(archivo, limite)
    relacionar_articulos(archivo, grafo, limite, saltos_linea)
    return grafo

