# -*- coding: utf-8 -*-
from collections import defaultdict
import sys
from utils_floyd_warshall import *
from estructuras_utils import *
from utils_red import *
COEFICIENTE_AMORTIGUACION = 0.85

class Red(object):

    def __init__(self, archivo, limite):
        '''Crea una nueva base de datos para una porcion de la wikipedia'''

        self.red_articulos = cargar_grafo(archivo, limite)
        self.cantidad_articulos = len(self.red_articulos)
        self.centralidad_articulos = None
        self.menu = {
        "Calcular pagerank de toda la red": self.calcular_pagerank,
        "Ver pagerank de un articulo": self.consultar_pagerank_articulo,
        "Mostrar un top de articulos con mayor pagerank":self.ver_top_pagerank,
        "Recorrido minimo de un articulo a otro": self.buscar_recorrido_minimo,
        "Centralidad": self.centralidad,
        "Diametro": self.diametro,
        "Ver todos los artículos a distancia <x> de cierto artículo" : self.distancias,
        "Hallar un ciclo de K articulos": self.ciclo
        }

    def ciclo(self):

        ''' Muestra algún ciclo de la red de al menos K articulos. En caso de no tener
            ningún ciclo con esa cantidad de vértices como mínimo, se informara con un
            mensaje por pantalla '''

        n = pedir_natural("Que longitud desea que tenga el ciclo?: ")
        extra = [n, None, self.red_articulos, None]
        contenedor_ciclo = 1
        for articulo in self.red_articulos:

            extra[len(extra) - 1] = articulo    
            self.red_articulos.dfs(articulo, buscar_ciclo_longitud_k, extra)
            if extra[contenedor_ciclo]:

                print "->".join(extra[contenedor_ciclo])
                return
            
        print "No se pudo hallar un ciclo de la longitud pedida en la red de articulos"

    def distancias(self):

        ''' Indica los articulos relacionados a las distintas distancias, 
            desde distancia 1 hasta la distancia deseada '''

        articulo = pedir_vertice(self.red_articulos, "Ingrese el articulo del cual quiere saber todos los articulos que se encuentren a distancia 1,2,...n: ")

        padres, orden = self.red_articulos.bfs(articulo)
        orden.pop(articulo)

        distancias = defaultdict(list)

        for articulo in orden:

            orden_articulo = orden[articulo]
            distancias[orden_articulo].append(articulo)
    
        for distancia in distancias:

            sys.stdout.write("\nArticulos a distancia "+str(distancia)+": ")
            for articulo in distancias[distancia]:

                msg = articulo+", "
                if articulo == distancias[distancia][len(distancias[distancia]) - 1]:

                    msg = articulo

                sys.stdout.write(msg)

            sys.stdout.write("\n")

    def diametro(self):

        ''' Indica el largo y el recorrido del camino mas corto mínimo
             más largo de toda la red '''      

        fin = self.red_articulos.diametro_fin()
        origen = self.red_articulos.diametro_origen()
        largo = self.red_articulos.diametro_largo()
        predecesores = self.red_articulos.predecesores_caminos_minimos
        camino_minimo = buscar_recorrido(origen, predecesores, fin, list())
        print "El diametro es: "+str(largo)+" con origen en: "+origen+", fin en : "+fin 
        print "El camino es: "+"->".join(camino_minimo) 

    def centralidad(self):

        '''La centralidad de un artículo denota la importancia de este. La centralidad
           se define como la cantidad de veces  que aparece un artículo
           entre los caminos mínimos. Se devuelven los K artículos más centrales.
           K es un numero que se le pedira al usuario
        '''

        cantidad_centrales = pedir_natural("Que cantidad de articulos centrales desea ver? (0 para cancelar): ")
        if not cantidad_centrales:

            return

        if not self.centralidad_articulos: 

            distancias = self.red_articulos.distancias_minimas
            predecesores = self.red_articulos.predecesores_caminos_minimos
            if not distancias:

                distancias, predecesores = self.red_articulos.floyd_warshall()

            centralidad_articulos = dict()        

            for articulo in distancias:

                for link in distancias[articulo]:

                    dist = distancias[articulo][link]
                    if dist != float("inf") and dist > 2: #si la distancia es 2 o menor, no hay intermedios
                        intermedios = buscar_recorrido(articulo, predecesores,link, list())
                        for x in range(1, len(intermedios) - 1):
                            centralidad_articulos[intermedios[x]] = centralidad_articulos.get(intermedios[x], 0) + 1
               
            self.centralidad_articulos = centralidad_articulos


        if cantidad_centrales > len(self.centralidad_articulos):

            cantidad_centrales = len(self.centralidad_articulos)

        top_centrales = obtener_mejores(self.centralidad_articulos, cantidad_centrales, len(self.centralidad_articulos))
        mostrar_tabla(top_centrales, True)


    def calcular_pagerank(self):
  
        '''Realiza K iteraciones del cálculo del pagerank. K un numero que se 
           le pedira al usuario
        '''

        iteraciones = pedir_natural("Ingrese el valor de k (k > 0) o 0 para cancelar: ")
        cantidad_vertices = self.cantidad_articulos
        red_articulos = self.red_articulos    

        while iteraciones > 0:

            for articulo in red_articulos:
        
                links = red_articulos.incidencias(articulo)
                
                sumatoria = 0            
                for link in links:

                    pagerank_link = red_articulos[link]
                    relacionados_a_link = len(red_articulos.adyacentes(link))
                    relacion_actual = pagerank_link/float(relacionados_a_link)
                    sumatoria += relacion_actual    

                pagerank_articulo = ((1 - COEFICIENTE_AMORTIGUACION) / cantidad_vertices) + (COEFICIENTE_AMORTIGUACION * sumatoria)
                red_articulos[articulo] = pagerank_articulo

            iteraciones -= 1

    def consultar_pagerank_articulo(self):

        '''Muestra el pagerank de un articulo en la red'''

        red_articulos = self.red_articulos
        continuar = True
    
        while continuar:

            articulo_interes =  pedir_vertice(red_articulos, "Ingrese el nombre del articulo: ")
            if articulo_interes == "-1":

                continuar = False
                continue

            print red_articulos[articulo_interes]
            continuar = False

    def buscar_recorrido_minimo(self):

        '''Busca el camino en la red para ir desde un articulo hasta otro
           de la manera mas corta posible
        '''

        red_articulos = self.red_articulos
        origen = pedir_vertice(red_articulos,"Ingrese el nombre del articulo de origen: ")
        destino = pedir_vertice(red_articulos,"Ingrese el nombre del articulo de destino: ")
        link_origen_destino = red_articulos.camino_minimo(origen,destino)
        if link_origen_destino:

            print "->".join(link_origen_destino)
    
        else:

            print "No hay links de "+origen+" con destino a "+destino


    def ver_top_pagerank(self):

        '''Muestra los K artículos con mayores valores de pagerank,
           con sus respectivos valores. K un numero que se le pedira
           al usuario'''

        red_articulos = self.red_articulos
        cantidad = pedir_natural("Cuantos elementos desea ver en el top? (0 para cancelar): ")
        if not cantidad:

            return

        if cantidad > self.cantidad_articulos:

            cantidad = self.cantidad_articulos

        top_articulos = obtener_mejores(red_articulos, cantidad, self.cantidad_articulos)
        mostrar_tabla(top_articulos, True)
