from red import *
import sys
from arch_utils import abrir_archivo
SALIR = '-1'
MENSAJE_ERROR = "Uso: main.py <cantidad_articulos> (cantidad_articulos >= 0)"
CONSULTAR_OPCION_USUARIO = "\nIngrese una opcion o -1 para finalizar: "
ERROR_INGRESO_USUARIO = "Debe ingresar un numero entre 1 y "
MENSAJE_INCIO_PROGRAMA = "Ingrese el nombre del archivo ya parseado: "
def main():
    '''Programa que modela una base de datos de Wikipedia,
       parseada por el programa wiki_parser.py'''
    
    if len(sys.argv) > 2 or len(sys.argv) == 1 or not sys.argv[1].isdigit() or int(sys.argv[1]) < 0:

        print MENSAJE_ERROR
        return

    cantidad_articulos = int(sys.argv[1])
    archivo = abrir_archivo(MENSAJE_INCIO_PROGRAMA)
    if archivo == SALIR:

        return

    red_wikipedia = Red(archivo, cantidad_articulos)
    archivo.close()    
    opciones = sorted(red_wikipedia.menu.keys())
    
    entrada = 0
    while entrada != SALIR:

        sys.stdout.write("\n")
        for i in range (len(opciones)):

            print str(i+1)+") "+opciones[i]

        entrada = raw_input(CONSULTAR_OPCION_USUARIO)
       
        if entrada == SALIR:

            continue
        
        if not entrada.isdigit() or int(entrada) < 1 or int(entrada) > len(opciones):

            entrada = 0
            print ERROR_INGRESO_USUARIO+str(len(opciones))
            continue

        red_wikipedia.menu[opciones[int(entrada) - 1]]()
            
main()
