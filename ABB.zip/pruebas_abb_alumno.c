/*
 * prueba_abb.c
 * Pruebas para el tipo de dato abstracto Tabla de abb
 */
#define _POSIX_C_SOURCE 200809L
#include "abb.h"
#include "cola.h"
#include "testing.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>  // For ssize_t in Linux.
#include <time.h>
bool multiplicar_datos(const char* clave, void* dato, void* factor);

bool guardar_claves(const char* clave, void* dato, void* cola);

/* ******************************************************************
 *                        PRUEBAS UNITARIAS
 * *****************************************************************/


static void prueba_crear_abb_vacio()
{
    abb_t* abb = abb_crear(strcmp,NULL);

    print_test("Prueba abb crear abb vacio", abb);
    print_test("Prueba abb la cantidad de elementos es 0", abb_cantidad(abb) == 0);
    print_test("Prueba abb obtener clave A, es NULL, no existe", !abb_obtener(abb, "A"));
    print_test("Prueba abb pertenece clave A, es false, no existe", !abb_pertenece(abb, "A"));
    print_test("Prueba abb borrar clave A, es NULL, no existe", !abb_borrar(abb, "A"));

    abb_destruir(abb);
}

static void prueba_iterar_abb_vacio()
{
    abb_t* abb = abb_crear(strcmp,NULL);
    abb_iter_t* iter = abb_iter_in_crear(abb);
    print_test("Prueba abb iter crear iterador abb vacio", iter);
    print_test("Prueba abb iter esta al final", abb_iter_in_al_final(iter));
    print_test("Prueba abb iter avanzar es false", !abb_iter_in_avanzar(iter));
    print_test("Prueba abb iter ver actual es NULL", !abb_iter_in_ver_actual(iter));

    abb_iter_in_destruir(iter);
    abb_destruir(abb);
}

static void prueba_abb_clave_vacia()
{
    abb_t* abb = abb_crear(strcmp,NULL);

    char *clave = "", *valor = "";

    print_test("Prueba abb insertar clave vacia", abb_guardar(abb, clave, valor));
    print_test("Prueba abb la cantidad de elementos es 1", abb_cantidad(abb) == 1);
    print_test("Prueba abb obtener clave vacia es valor", abb_obtener(abb, clave) == valor);
    print_test("Prueba abb pertenece clave vacia, es true", abb_pertenece(abb, clave));
    print_test("Prueba abb borrar clave vacia, es valor", abb_borrar(abb, clave) == valor);
    print_test("Prueba abb la cantidad de elementos es 0", abb_cantidad(abb) == 0);

    abb_destruir(abb);
}

static void prueba_abb_valor_null()
{
    abb_t* abb = abb_crear(strcmp,NULL);

    char *clave = "", *valor = NULL;

    /* Inserta 1 valor y luego lo borra */
    print_test("Prueba abb insertar clave vacia valor NULL", abb_guardar(abb, clave, valor));
    print_test("Prueba abb la cantidad de elementos es 1", abb_cantidad(abb) == 1);
    print_test("Prueba abb obtener clave vacia es valor NULL", abb_obtener(abb, clave) == valor);
    print_test("Prueba abb pertenece clave vacia, es true", abb_pertenece(abb, clave));
    print_test("Prueba abb borrar clave vacia, es valor NULL", abb_borrar(abb, clave) == valor);
    print_test("Prueba abb la cantidad de elementos es 0", abb_cantidad(abb) == 0);

    abb_destruir(abb);
}

static void prueba_abb_insertar()
{

    abb_t* abb = abb_crear(strcmp,NULL);

    char *clave1 = "perro", *valor1 = "guau";
    char *clave2 = "gato", *valor2 = "miau";
    char *clave3 = "vaca", *valor3 = "mu";

    /* Inserta 1 valor y luego lo borra */
    print_test("Prueba abb insertar clave1", abb_guardar(abb, clave1, valor1));
    print_test("Prueba abb la cantidad de elementos es 1", abb_cantidad(abb) == 1);
    print_test("Prueba abb obtener clave1 es valor1", abb_obtener(abb, clave1) == valor1);
    print_test("Prueba abb obtener clave1 es valor1", abb_obtener(abb, clave1) == valor1);
    print_test("Prueba abb pertenece clave1, es true", abb_pertenece(abb, clave1));
    print_test("Prueba abb borrar clave1, es valor1", abb_borrar(abb, clave1) == valor1);
    print_test("Prueba abb la cantidad de elementos es 0", abb_cantidad(abb) == 0);

    /* Inserta otros 2 valores y no los borra (se destruyen con el abb) */
    print_test("Prueba abb insertar clave2", abb_guardar(abb, clave2, valor2));
    print_test("Prueba abb la cantidad de elementos es 1", abb_cantidad(abb) == 1);
    print_test("Prueba abb obtener clave2 es valor2", abb_obtener(abb, clave2) == valor2);
    print_test("Prueba abb obtener clave2 es valor2", abb_obtener(abb, clave2) == valor2);
    print_test("Prueba abb pertenece clave2, es true", abb_pertenece(abb, clave2));

    print_test("Prueba abb insertar clave3", abb_guardar(abb, clave3, valor3));
    print_test("Prueba abb la cantidad de elementos es 2", abb_cantidad(abb) == 2);
    print_test("Prueba abb obtener clave3 es valor3", abb_obtener(abb, clave3) == valor3);
    print_test("Prueba abb obtener clave3 es valor3", abb_obtener(abb, clave3) == valor3);
    print_test("Prueba abb pertenece clave3, es true", abb_pertenece(abb, clave3));

    abb_destruir(abb);
}

static void prueba_abb_reemplazar()
{
    abb_t* abb = abb_crear(strcmp,NULL);

    char *clave1 = "perro", *valor1a = "guau", *valor1b = "warf";
    char *clave2 = "gato", *valor2a = "miau", *valor2b = "meaow";

    /* Inserta 2 valores y luego los reemplaza */
    print_test("Prueba abb insertar clave1", abb_guardar(abb, clave1, valor1a));
    print_test("Prueba abb obtener clave1 es valor1a", abb_obtener(abb, clave1) == valor1a);
    print_test("Prueba abb obtener clave1 es valor1a", abb_obtener(abb, clave1) == valor1a);
    print_test("Prueba abb insertar clave2", abb_guardar(abb, clave2, valor2a));
    print_test("Prueba abb obtener clave2 es valor2a", abb_obtener(abb, clave2) == valor2a);
    print_test("Prueba abb obtener clave2 es valor2a", abb_obtener(abb, clave2) == valor2a);
    print_test("Prueba abb la cantidad de elementos es 2", abb_cantidad(abb) == 2);

    print_test("Prueba abb insertar clave1 con otro valor", abb_guardar(abb, clave1, valor1b));
    print_test("Prueba abb obtener clave1 es valor1b", abb_obtener(abb, clave1) == valor1b);
    print_test("Prueba abb obtener clave1 es valor1b", abb_obtener(abb, clave1) == valor1b);
    print_test("Prueba abb insertar clave2 con otro valor", abb_guardar(abb, clave2, valor2b));
    print_test("Prueba abb obtener clave2 es valor2b", abb_obtener(abb, clave2) == valor2b);
    print_test("Prueba abb obtener clave2 es valor2b", abb_obtener(abb, clave2) == valor2b);
    print_test("Prueba abb la cantidad de elementos es 2", abb_cantidad(abb) == 2);

    abb_destruir(abb);
}

static void prueba_abb_reemplazar_con_destruir()
{
    abb_t* abb = abb_crear(strcmp,free);

    char *clave1 = "perro", *valor1a, *valor1b;
    char *clave2 = "gato", *valor2a, *valor2b;

    /* Pide memoria para 4 valores */
    valor1a = malloc(10 * sizeof(char));
    valor1b = malloc(10 * sizeof(char));
    valor2a = malloc(10 * sizeof(char));
    valor2b = malloc(10 * sizeof(char));

    /* Inserta 2 valores y luego los reemplaza (debe liberar lo que reemplaza) */
    print_test("Prueba abb insertar clave1", abb_guardar(abb, clave1, valor1a));
    print_test("Prueba abb obtener clave1 es valor1a", abb_obtener(abb, clave1) == valor1a);
    print_test("Prueba abb obtener clave1 es valor1a", abb_obtener(abb, clave1) == valor1a);
    print_test("Prueba abb insertar clave2", abb_guardar(abb, clave2, valor2a));
    print_test("Prueba abb obtener clave2 es valor2a", abb_obtener(abb, clave2) == valor2a);
    print_test("Prueba abb obtener clave2 es valor2a", abb_obtener(abb, clave2) == valor2a);
    print_test("Prueba abb la cantidad de elementos es 2", abb_cantidad(abb) == 2);

    print_test("Prueba abb insertar clave1 con otro valor", abb_guardar(abb, clave1, valor1b));
    print_test("Prueba abb obtener clave1 es valor1b", abb_obtener(abb, clave1) == valor1b);
    print_test("Prueba abb obtener clave1 es valor1b", abb_obtener(abb, clave1) == valor1b);
    print_test("Prueba abb insertar clave2 con otro valor", abb_guardar(abb, clave2, valor2b));
    print_test("Prueba abb obtener clave2 es valor2b", abb_obtener(abb, clave2) == valor2b);
    print_test("Prueba abb obtener clave2 es valor2b", abb_obtener(abb, clave2) == valor2b);
    print_test("Prueba abb la cantidad de elementos es 2", abb_cantidad(abb) == 2);

    /* Se destruye el abb (se debe liberar lo que quedó dentro) */
    abb_destruir(abb);
}

static void prueba_abb_borrar()
{
    abb_t* abb = abb_crear(strcmp,NULL);

    char *clave1 = "perro", *valor1 = "guau";
    char *clave2 = "gato", *valor2 = "miau";
    char *clave3 = "vaca", *valor3 = "mu";

    /* Inserta 3 valores y luego los borra */
    print_test("Prueba abb insertar clave1", abb_guardar(abb, clave1, valor1));
    print_test("Prueba abb insertar clave2", abb_guardar(abb, clave2, valor2));
    print_test("Prueba abb insertar clave3", abb_guardar(abb, clave3, valor3));

    /* Al borrar cada elemento comprueba que ya no está pero los otros sí. */
    print_test("Prueba abb pertenece clave3, es verdadero", abb_pertenece(abb, clave3));
    print_test("Prueba abb borrar clave3, es valor3", abb_borrar(abb, clave3) == valor3);
    print_test("Prueba abb borrar clave3, es NULL", !abb_borrar(abb, clave3));
    print_test("Prueba abb pertenece clave3, es falso", !abb_pertenece(abb, clave3));
    print_test("Prueba abb obtener clave3, es NULL", !abb_obtener(abb, clave3));
    print_test("Prueba abb la cantidad de elementos es 2", abb_cantidad(abb) == 2);

    print_test("Prueba abb pertenece clave1, es verdadero", abb_pertenece(abb, clave1));
    print_test("Prueba abb borrar clave1, es valor1", abb_borrar(abb, clave1) == valor1);
    print_test("Prueba abb borrar clave1, es NULL", !abb_borrar(abb, clave3));
    print_test("Prueba abb pertenece clave1, es falso", !abb_pertenece(abb, clave1));
    print_test("Prueba abb obtener clave1, es NULL", !abb_obtener(abb, clave1));
    print_test("Prueba abb la cantidad de elementos es 1", abb_cantidad(abb) == 1);

    print_test("Prueba abb pertenece clave2, es verdadero", abb_pertenece(abb, clave2));
    print_test("Prueba abb borrar clave2, es valor2", abb_borrar(abb, clave2) == valor2);
    print_test("Prueba abb borrar clave2, es NULL", !abb_borrar(abb, clave3));
    print_test("Prueba abb pertenece clave2, es falso", !abb_pertenece(abb, clave2));
    print_test("Prueba abb obtener clave2, es NULL", !abb_obtener(abb, clave2));
    print_test("Prueba abb la cantidad de elementos es 0", abb_cantidad(abb) == 0);

    abb_destruir(abb);
}

static void pruebas_abb_complejos(void)
{
	abb_t* abb = abb_crear(strcmp,NULL);
	char* in[]= {"M","X","Y","V","O","J","I","D","G","E","F","A","C","B","W","Z","K","P","Q",NULL};	
	char* ord[] = {"A","B","C","D","E","F","G","I","J","K","M","O","P","Q","V","W","X","Y","Z",NULL};
	size_t i;
	size_t cantidad_elementos = 0;
	for (i = 0; in[i] != NULL; i++){
		abb_guardar(abb,in[i],(void*)i);
		cantidad_elementos++;
	}
	abb_iter_t* iter = abb_iter_in_crear(abb);
	size_t errores_orden = 0;
	for (i = 0; !abb_iter_in_al_final(iter); abb_iter_in_avanzar(iter),i++){
		if (strcmp(abb_iter_in_ver_actual(iter),ord[i]) != 0){
			errores_orden++;
		}
	}
	abb_iter_in_destruir(iter);

	/*Se realizaran algunos borrados y luego se comprobara que el arbol siga en orden correcto*/

	print_test("El recorrido del abb in orden es correcto",errores_orden == 0);	
	print_test("Borrado 1",abb_borrar(abb,"D") == (void*)7);
	print_test("Borrado 2",abb_borrar(abb,"O") == (void*)4);
	print_test("Borrado 3",abb_borrar(abb,"M") == (void*)0);
	print_test("Borrado 4",abb_borrar(abb,"V") == (void*)3);
	print_test("Borrado 5",abb_borrar(abb,"P") == (void*)17);
	print_test("La cantidad de elementos es correcta",cantidad_elementos-5 == abb_cantidad(abb));
	char* ord2[] = {"A","B","C","E","F","G","I","J","K","Q","W","X","Y","Z",NULL};
	
	iter = abb_iter_in_crear(abb);
	for (i = 0; !abb_iter_in_al_final(iter); abb_iter_in_avanzar(iter),i++){
		if (strcmp(abb_iter_in_ver_actual(iter),ord2[i]) != 0){
			errores_orden++;
		}
	
	}
	abb_iter_in_destruir(iter);
	print_test("El recorrido del abb in orden es correcto",errores_orden == 0);	
	/*Se realizaran inserciones y luego se comprobara que el arbol este en orden*/

	print_test("Guardado 1",abb_guardar(abb,"N",NULL));
	print_test("Guardado 2",abb_guardar(abb,"L",NULL));
	print_test("Guardado 3",abb_guardar(abb,"D",NULL));
	print_test("Guardado 4",abb_guardar(abb,"M",NULL));
	print_test("Guardado 5",abb_guardar(abb,"O",NULL));
	print_test("La cantidad de elementos es correcta",cantidad_elementos == abb_cantidad(abb));
	char* ord3[] = {"A","B","C","D","E","F","G","I","J","K","L","M","N","O","Q","W","X","Y","Z",NULL};
	iter = abb_iter_in_crear(abb);
	for (i = 0; !abb_iter_in_al_final(iter); abb_iter_in_avanzar(iter),i++){
		if (strcmp(abb_iter_in_ver_actual(iter),ord3[i]) != 0){
			errores_orden++;
		}
	}
	abb_iter_in_destruir(iter);
	print_test("El recorrido del abb in orden es correcto",errores_orden == 0);	
	abb_destruir(abb);	
}

int comparar(const char *str1, const char *str2)
{	
	size_t x = strtol(str1,NULL,10);
	size_t y = strtol(str2,NULL,10);
	if (x == y){
		return 0;
	}
	if (x < y){
		return -1;
	}
	return 1;		
}

static void pruebas_iter_externo(void)
{

	printf("%s","~~~ CREAR ~~~");
	abb_t *abb = abb_crear(comparar, NULL);
	int a = 7;
	int b = 1;
	int c = 3;
	int *n1 = &a;
	int *n2 = &b;
	int *n3 = &c;
	const char* c1 = "10'";
	const char* c2 = "8";
	const char* c3 = "15";
	abb_guardar(abb, c1, (void*)n1);
	abb_guardar(abb, c2, (void*)n2);
	abb_guardar(abb, c3, (void*)n3);
	abb_iter_t *iter = abb_iter_in_crear(abb);
	print_test("abb iter fue creado",iter);	
	print_test("iter avanzar", abb_iter_in_avanzar(iter));
	print_test("iter avanzar", abb_iter_in_avanzar(iter));
	print_test("iter ver actual es c2", comparar(abb_iter_in_ver_actual(iter),c3) == 0);
	print_test("iter al final es false3", !abb_iter_in_al_final(iter));
	print_test("iter avanzar", abb_iter_in_avanzar(iter));
	print_test("iter ver actual es NULL", abb_iter_in_ver_actual(iter) == NULL);
	print_test("iter avanzar es false", !abb_iter_in_avanzar(iter));
	print_test("iter al final", abb_iter_in_al_final(iter));
	abb_iter_in_destruir(iter);
	print_test("El iterador fue destruido",true);
	abb_destruir(abb);
}

bool multiplicar_datos(const char* clave, void* dato, void* factor)
{
	int *multiplicando = (int*)factor;
	int *numero = (int*)dato;
	*numero*=*multiplicando;
	return true;
}
//Encola claves que son menores a la cola recibida como void*
bool guardar_claves(const char* clave, void* dato, void* cola)
{
	
	cola_t *cola_claves = (cola_t*)cola;
	if (strcmp(clave,(char*)cola_ver_primero(cola)) < 0){
		cola_encolar(cola_claves,(void*)clave);
		return true;
		}
	else{
		return false;
		}
}

static void pruebas_abb_iter_interno(void)
{

	abb_t* arbol_enteros = abb_crear(strcmp,free);
	char* claves[] = {"G","O","C","A","D","K","H","L",NULL};
	size_t i;

	for (i = 0; claves[i] != NULL; i++){
		size_t *dato_entero = malloc(sizeof(size_t));
		*dato_entero = i;
		abb_guardar(arbol_enteros,claves[i],(void*)dato_entero);
		}

	int* factor = malloc(sizeof(int));
	*factor = 2;
	abb_in_order(arbol_enteros,multiplicar_datos,(void*)factor);
	int resultados[8] = {3,2,4,0,6,5,7,1};
	abb_iter_t* iter = abb_iter_in_crear(arbol_enteros);
	size_t errores = 0;

	for (i = 0; !abb_iter_in_al_final(iter); i++){		
		const char *clave = abb_iter_in_ver_actual(iter);
		void *dato = abb_obtener(arbol_enteros,clave);
		int valor = *(int*)dato;
		if (valor != *factor*resultados[i]){
			errores++;
		}
		abb_iter_in_avanzar(iter);
	}
	print_test("Los valores del ABB de enteros fueron multiplicados",errores == 0);	
	abb_iter_in_destruir(iter);
	free(factor);
	cola_t* cola = cola_crear();
	cola_encolar(cola,(void*)"K");
	abb_in_order(arbol_enteros,guardar_claves,cola);
	char* primero = cola_ver_primero(cola);
	while (!cola_esta_vacia(cola)){
		if (strcmp((char*)cola_desencolar(cola),primero) > 0){
			errores++;
		}
	}
	
	print_test("Las claves correctas fueron guardadas",errores == 0);
	cola_destruir(cola,NULL);	
    abb_destruir(arbol_enteros);
}


//Algoritmo copiado de: 
//http://codereview.stackexchange.com/questions/29198/random-string-generator-in-c
static char *rand_string(char *str, size_t size)
{
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    if (size) {
        --size;
        for (size_t n = 0; n < size; n++) {
            int key = rand() % (int)(sizeof(charset) - 1);
            str[n] = charset[key];
        }
        str[size] = '\0';
    }
    return str;
}

char* rand_string_alloc(size_t size)
{
     char *s = malloc(size + 1);
     if (s) {
         rand_string(s, size);
     }
     return s;
}


static void pruebas_abb_volumen(size_t cantidad_claves)
{
	abb_t* abb = abb_crear(strcmp,NULL);
	char** claves = malloc(sizeof(char*)*(cantidad_claves+1));
	claves[cantidad_claves] = NULL;
	for (size_t x = 0; x < cantidad_claves; x++){
		const size_t longitud_claves = 5;
		char* randomkey = rand_string_alloc(longitud_claves);
		abb_guardar(abb,randomkey,NULL);
		claves[x] = randomkey;
		}
	abb_iter_t* iter = abb_iter_in_crear(abb);
	const char* anterior = abb_iter_in_ver_actual(iter);
	size_t errores = 0;
	for (size_t i = 0; i < cantidad_claves; i++);
	{
		abb_iter_in_avanzar(iter);
		const char* siguiente = abb_iter_in_ver_actual(iter);
		anterior = siguiente;
		if (strcmp(anterior,siguiente) > 0)
		{
			errores++;
		}
	}
	
	abb_iter_in_destruir(iter);
	print_test("El arbol esta en el orden correcto",errores == 0);

	size_t j = 0;
	while (claves[j] != NULL){
		abb_borrar(abb,claves[j]);
		free(claves[j]);
		j++;
		}
	free(claves);
	print_test("Las claves han sido eliminadas y el arbol borrado",true);
	abb_destruir(abb);
}   
		
/* ******************************************************************
 *                        FUNCIÓN PRINCIPAL
 * *****************************************************************/


void pruebas_abb_alumno()
{
    /* Ejecuta todas las pruebas unitarias. */
    prueba_crear_abb_vacio();
    prueba_iterar_abb_vacio();
    prueba_abb_insertar();
    prueba_abb_reemplazar();
    prueba_abb_reemplazar_con_destruir();
    prueba_abb_borrar();
    prueba_abb_clave_vacia();
    prueba_abb_valor_null();
	pruebas_iter_externo();
	pruebas_abb_complejos();
	pruebas_abb_iter_interno();
	pruebas_abb_volumen(50000);
}

