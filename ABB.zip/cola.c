#include "cola.h"
#include <stdlib.h>
#include <stdio.h>
typedef struct nodo{
	void* dato;
	struct nodo* siguiente;
	} nodo_cola_t;

//Crea un nuevo nodo
nodo_cola_t* nodo_crear();

nodo_cola_t* nodo_crear(){

	nodo_cola_t* nodo_nuevo = malloc(sizeof(nodo_cola_t));
	
	if (nodo_nuevo){
		nodo_nuevo->siguiente = NULL; 
		return nodo_nuevo;
		}
	return NULL;
	}

struct cola{
	nodo_cola_t* primero;
	nodo_cola_t* ultimo;
	};

cola_t* cola_crear(void){
	cola_t* cola_nueva = malloc(sizeof(cola_t));
	if (cola_nueva){
		cola_nueva->primero = NULL;
		cola_nueva->ultimo = NULL;
		return cola_nueva;
		}
	return NULL;
	}

void cola_destruir(cola_t *cola, void destruir_dato(void*)){
	if (destruir_dato){
		while (!cola_esta_vacia(cola)){
			destruir_dato(cola->primero->dato);
			cola_desencolar(cola);
			}
		}
	while (!cola_esta_vacia(cola)){ //si se ejecuto el bloque anterior, ya esta vacia y no hace nada
		cola_desencolar(cola);
		}
	free(cola);
	}

bool cola_esta_vacia(const cola_t* cola){
	return !cola->primero;
	}

bool cola_encolar(cola_t* cola, void* valor){
	nodo_cola_t* nodo_nuevo = nodo_crear();
	if (!nodo_nuevo){
		return false;
		}
	nodo_nuevo->dato = valor;
	if (cola->primero == NULL){
		cola->primero = nodo_nuevo;
		cola->ultimo = nodo_nuevo;
		}
	else {
		cola->ultimo->siguiente = nodo_nuevo;
		cola->ultimo = nodo_nuevo;
		}
	return true;
	}
void* cola_ver_primero(const cola_t *cola){
	if (!cola_esta_vacia(cola)){
		void* primero = cola->primero->dato;
		return primero;
		}
	return NULL;
	}
void* cola_desencolar(cola_t *cola){
	if (!cola_esta_vacia(cola)){
		nodo_cola_t* primer_nodo = cola->primero; //necesito guardarlo para destruirlo despues
		void* primer_valor = primer_nodo->dato;
		cola->primero = primer_nodo->siguiente;
		free(primer_nodo);
		return primer_valor;
		}
	return NULL;
	}
