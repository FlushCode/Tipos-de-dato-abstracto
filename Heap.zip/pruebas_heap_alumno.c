#include "heap.h"
#include "testing.h"
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>

int prioridad_enteros(const void *a,const void *b)
{
	if (*(int*)a == *(int*)b)
		{return 0;}

	else if (*(int*)a<*(int*)b)
        
		{return -1;}
	return 1;
}
//FUNCION DE http://stackoverflow.com/questions/2509679/how-to-generate-a-random-number-from-within-a-range
// Assumes 0 <= max <= RAND_MAX
// Returns in the half-open interval [0, max]
int rand_interval(long max) {
	unsigned long
    // max <= RAND_MAX < ULONG_MAX, so this is okay.
    num_bins = (unsigned long) max + 1,
    num_rand = (unsigned long) RAND_MAX + 1,
    bin_size = num_rand / num_bins,
    defect   = num_rand % num_bins;

  long x;
  do {
   x = rand();
  }
  // This is carefully written not to overflow
  while (num_rand - defect <= (unsigned long)x);

  // Truncated division is intentional
  return (int)(x/bin_size);
}

static void pruebas_heap_vacio(void)
{
	puts("\n***PRUEBAS HEAP VACIO***\n");
	heap_t* heap_vacio = heap_crear(NULL);
	print_test("Heap creado",heap_vacio);
	print_test("Contiene 0 elementos",heap_cantidad(heap_vacio) == 0);
	print_test("El maximo es NULL",heap_ver_max(heap_vacio) == NULL);
	print_test("Desencolar devuelve NULL",heap_desencolar(heap_vacio) == NULL);		
	print_test("Contiene 0 elementos",heap_cantidad(heap_vacio) == 0);
    print_test("El heap esta vacio",heap_esta_vacio(heap_vacio) == true);
	print_test("El maximo es NULL",heap_ver_max(heap_vacio) == NULL);
	heap_destruir(heap_vacio,NULL);		
	print_test("Destruir heap",true);
}

static void pruebas_heap_varios_elementos(void)
{
	puts("\n***PRUEBAS HEAP ENCOLANDO VARIOS ENTEROS***\n");
	heap_t* heap = heap_crear(prioridad_enteros);
	print_test("Heap creado",heap);
	print_test("Contiene 0 elementos",heap_cantidad(heap) == 0);
	print_test("El maximo es NULL",heap_ver_max(heap) == NULL);
	print_test("Desencolar devuelve NULL",heap_desencolar(heap) == NULL);		
	print_test("Contiene 0 elementos",heap_cantidad(heap) == 0);
	print_test("El maximo es NULL",heap_ver_max(heap) == NULL);
	
	int a = 4;
	int b = 7;
	int c = 2;

	int *x = &a;
	int *y = &b;
	int *z = &c;

	print_test("Encolar el 4",heap_encolar(heap,(void*)x));
	print_test("Maximo es 4",*(int*)heap_ver_max(heap) == 4);
    print_test("Cantidad es 1",heap_cantidad(heap) == 1);
	print_test("Encolar el 2",heap_encolar(heap,(void*)z));
    print_test("Maximo es 4",*(int*)heap_ver_max(heap) == 4);
    print_test("Cantidad es 2",heap_cantidad(heap) == 2);
	print_test("Encolar el 7",heap_encolar(heap,(void*)y));
    print_test("Cantidad es 3",heap_cantidad(heap) == 3);
    print_test("Maximo es 7",*(int*)heap_ver_max(heap) == 7);
    print_test("Desencolar devuelve 7",*(int*)heap_desencolar(heap) == 7);
    print_test("Cantidad es 2",heap_cantidad(heap) == 2);    
    print_test("Maximo es 4",*(int*)heap_ver_max(heap) == 4);
    print_test("Desencolar devuelve 4",*(int*)heap_desencolar(heap) == 4);
    print_test("Cantidad es 1",heap_cantidad(heap) == 1);
    print_test("Desencolar devuelve 2",*(int*)heap_desencolar(heap) == 2);
    print_test("Cantidad es 0",heap_cantidad(heap) == 0);
    print_test("El heap esta vacio",heap_esta_vacio(heap) == true);
    print_test("Desencolar devuelve NULL",heap_desencolar(heap) == NULL);
    print_test("Cantidad es 0",heap_cantidad(heap) == 0);
    print_test("Encolar el 7",heap_encolar(heap,(void*)y));
    print_test("Maximo es 7",*(int*)heap_ver_max(heap) == 7);
    print_test("Cantidad es 1",heap_cantidad(heap) == 1);
    print_test("Desencolar devuelve 7",*(int*)heap_desencolar(heap) == 7);
    print_test("Cantidad es 0",heap_cantidad(heap) == 0);
    print_test("El heap esta vacio",heap_esta_vacio(heap) == true);
    print_test("Desencolar devuelve NULL",heap_desencolar(heap) == NULL);
    print_test("Encolar el 2",heap_encolar(heap,(void*)z));
    print_test("Maximo es 2",*(int*)heap_ver_max(heap) == 2);
    print_test("Encolar el 4",heap_encolar(heap,(void*)x));
    print_test("Maximo es 4",*(int*)heap_ver_max(heap) == 4);
    print_test("Desencolar devuelve 4",*(int*)heap_desencolar(heap) == 4);
    print_test("Maximo es 2",*(int*)heap_ver_max(heap) == 2);
    
    
    

	heap_destruir(heap,NULL);	
	print_test("Destruir heap",true);
}

static void pruebas_heap_arreglo(const size_t tam_array)
{
    puts("\n**Crear un heap a partir de un arreglo**\n");
    void** arreglo = malloc((sizeof(void*))*tam_array);
    for (size_t i = 0; i < tam_array; i++)
    {
        int *a = malloc(sizeof(int));
		*a = rand_interval(tam_array);
		arreglo[i] = (void*)a;
    }
    heap_t* heap_arreglo = heap_crear_arr(arreglo,tam_array,prioridad_enteros);
    print_test("Creado el heap a partir de un arreglo",heap_arreglo);
    int maximo = *(int*)heap_ver_max(heap_arreglo);
    bool es_heap = true;
    while (!heap_esta_vacio(heap_arreglo))
    {
        int actual = *(int*)heap_desencolar(heap_arreglo);
        if (actual > maximo)
        {
            es_heap = false;
            break;
        }
        maximo = actual;
    }
    for (size_t i = 0; i < tam_array; i++)
    {
        free(arreglo[i]);
    }
    print_test("Se comprobo que la estructura era un heap",es_heap == true);
    heap_destruir(heap_arreglo,NULL);
    print_test("El heap creado a partir de un arreglo fue destruido",true);
    free(arreglo);
}
        
static void pruebas_heap_volumen_random(const int cantidad)
{
	puts("\n***Pruebas de volumen con elementos random***\n");
	heap_t* heap = heap_crear(prioridad_enteros);
	for (int i = cantidad; i >= 0; i--)						 
	{	int *a = malloc(sizeof(int));
		*a = rand_interval(cantidad);
		heap_encolar(heap,(void*)a);
	} 
	bool desencolo_menor = false;
	int mayor = cantidad+1;
	size_t cantidad_elementos = heap_cantidad(heap);
	bool cantidad_erronea_elementos= false;
	for (int i = 0; i < cantidad+1; i++)						 
	{	
	
		void* desencolado = heap_desencolar(heap);
		int valor = *(int*)desencolado;
		if (valor > mayor)
		{
			printf("valor vale %d mayor vale %d\n",valor,mayor);
			desencolo_menor = true;
			break;
		}
		size_t cantidad_actual = heap_cantidad(heap);
		if (cantidad_actual != cantidad_elementos-1)
		{
			cantidad_erronea_elementos = true;
			break;
		}
		cantidad_elementos = cantidad_actual;
		mayor = valor;	
		free(desencolado);
	}
	print_test("Desencolo en orden correcto",desencolo_menor == false);
	print_test("Cantidad correcta",cantidad_erronea_elementos == false);
	heap_destruir(heap,free);
}

static void pruebas_heap_volumen(const int cantidad)
{
	puts("\n***Pruebas de volumen***\n");
	heap_t* heap = heap_crear(prioridad_enteros);
	for (int i = cantidad; i >= 0; i--)						 
	{	int *a = malloc(sizeof(int));
		*a = i;
		heap_encolar(heap,(void*)a);
	} 
	bool desencolo_menor = false;
	int mayor = cantidad+1;
	size_t cantidad_elementos = heap_cantidad(heap);
	bool cantidad_erronea_elementos= false;
	for (int i = 0; i < cantidad+1; i++)						 
	{	
	
		void* desencolado = heap_desencolar(heap);
		int valor = *(int*)desencolado;
		if (valor != mayor-1)
		{
			desencolo_menor = true;
			break;
		}
		size_t cantidad_actual = heap_cantidad(heap);
		if (cantidad_actual != cantidad_elementos-1)
		{
			cantidad_erronea_elementos = true;
			break;
		}
		cantidad_elementos = cantidad_actual;
		mayor = valor;	
		free(desencolado);
	}
	print_test("Desencolo en orden correcto",desencolo_menor == false);
	print_test("Cantidad correcta",cantidad_erronea_elementos == false);
	heap_destruir(heap,free);
}

static void pruebas_heap_sort(const size_t tam_array)
{
    puts("\n**Pruebas de ordenar un arreglo utilizando heap_sort**\n");
    void** arreglo = malloc((sizeof(void*))*tam_array);
    for (size_t i = 0; i < tam_array; i++)
    {
        int *a = malloc(sizeof(int));
		*a = rand_interval(tam_array);
		arreglo[i] = (void*)a;
    }
    heap_sort(arreglo,tam_array,prioridad_enteros);
    bool orden_correcto = true;
    int anterior = -1;
    for (size_t i = 0; i < tam_array; i++)
    {
        int actual = *(int*)arreglo[i];
        if (actual < anterior)
        {
            orden_correcto = false;
            break;
        }
        anterior = actual;
        free(arreglo[i]);
    }
    print_test("El arreglo fue ordenado exitosamente",orden_correcto == true);
    free(arreglo);   
    }        
    
    
    
void pruebas_heap_alumno(){
	pruebas_heap_vacio();
	pruebas_heap_varios_elementos();
    pruebas_heap_arreglo(47329);
	pruebas_heap_volumen(1238);
	pruebas_heap_volumen_random(438);
    pruebas_heap_sort(758);
	}



