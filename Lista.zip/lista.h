#ifndef LISTA_H
#define LISTA_H

#include <stdbool.h>
#include <stddef.h>

struct lista;
typedef struct lista lista_t;

/***************************************
*				       *
*	PRIMITIVAS DE LA LISTA         *
*				       *
***************************************/

//Crea una lista.
//Post: devuelve una nueva lista vacía
lista_t *lista_crear(void);

// Destruye la lista. Si se recibe la función destruir_dato por parámetro,
// para cada uno de los elementos de la lista llama a destruir_dato.
// Pre: la lista fue creada. destruir_dato es una función capaz de destruir
// los datos de la lista, o NULL en caso de que no se la utilice.
// Post: se eliminaron todos los elementos de la lista.
void lista_destruir(lista_t *lista, void destruir_dato(void *));

// Devuelve verdadero o falso, según si la lista tiene o no elementos insertados.
// Pre: la cola lista creada.
bool lista_esta_vacia(const lista_t *lista);

// Agrega un nuevo elemento al principio de la lista. Devuelve falso en caso de error.
// Pre: la lista fue creada.
// Post: se agregó un nuevo elemento a la lista, dato se encuentra al principio
// de la lista.
bool lista_insertar_primero(lista_t *lista, void *dato);

// Obtiene el dato del primer elemento de la lista. Si la lista tiene
// elementos, se devuelve el dato del primero, si está vacía devuelve NULL.
// Pre: la lista fue creada.
// Post: se devolvió el primer elemento de la lista, cuando no está vacía.
void *lista_ver_primero(const lista_t *lista);

// Agrega un nuevo elemento al final de la lista. Devuelve falso en caso de error.
// Pre: la lista fue creada.
// Post: se agregó un nuevo elemento a la lista, dato se encuentra al final
// de la lista.
bool lista_insertar_ultimo(lista_t *lista, void *dato);

// Saca el primer elemento de la lista. Si la lista tiene elementos, se quita el
// primero de la lista, y se devuelve su dato, si está vacía, devuelve NULL.
// Pre: la lista fue creada.
// Post: se devolvió el dato del primer elemento anterior, la lista
// contiene un elemento menos, si la lista no estaba vacía.
void *lista_borrar_primero(lista_t *lista);

//Devuelve el largo de la lista, si la lista es vacia devuelve 0.
//Post: la lista fue creada
size_t lista_largo(const lista_t *lista);

struct lista_iter;
typedef struct lista_iter lista_iter_t;

//Crea un nuevo iterador
//Pre: debe recibir una lista ya creada
//Post: devuelve un iterador que apunta al primer elemento de la lista,
//si la lista esta vacia, el iterador apunta a NULL
lista_iter_t* lista_iter_crear(lista_t *lista);

//Destruye al iterador
//Pre: el iterador fue creado
void lista_iter_destruir(lista_iter_t *iter);

//Devuelve verdadero o falso, según se encuentre al final de la lista o no
//Pre: el iterador fue creado
//Post: se devuelve true si el iterador ha avanzado un elemento mas despues del
//ultimo de la lista, o si se encuentra apuntando a NULL (si se creo cuando la lista
//estaba vacia), caso contrario, false
bool lista_iter_al_final(const lista_iter_t *iter);

//Muestra el dato al que esta apuntando el iterador en la lista
//Pre: El iterador fue creado
void *lista_iter_ver_actual(const lista_iter_t *iter);

//Avanza el iterador al siguiente dato en la lista
//Pre: el iterador fue creado
//Post: devuelve verdadero si se avanzo, falso en caso contrario, se 
//devuelve false en el caso en el que se esta apuntando a NULL y la lista
//no es vacia, esto quiere decir que se avanzo un elemento mas luego del final,
//si el iterador se creo cuando la lista estaba vacia, se insertaron elementos y luego
//intento avanzar, lo hará y devolverá verdadero, en cambio en una lista vacia, devuelve false
bool lista_iter_avanzar(lista_iter_t *iter);

//Inserta un elemento en la posicion en la que apunta el iterador en la lista
//Pre: el iterador fue creado y debe recibir un dato generico
//Post: Inserta el elemento en donde se esta apuntando, el largo de la lista se 
//actualizara, si se inserta al final o al principio tambien, y se puede utilizar para
//insertar en listas vacias
bool lista_iter_insertar(lista_iter_t *iter, void *dato);

//Elimina y devuelve el dato al que el iterador apunta
//Pre: el iterador fue creado
//Post: Devuelve y elimina de la lista al dato apuntado, actualizandola correctamente,
//si la lista esta vacia, devuelve NULL y la lista no sufre ningun cambio
void *lista_iter_borrar(lista_iter_t *iter);

//Itera internamente sobre la lista, si los parametros visitar y extra no son NULL
//aplica la funcion visitar a cada dato de la lista, y si la funcion requiere un parametro
//extra se debe pasar como tercer parametro
//Pre: la lista fue creada
//Post: los elementos de la lista se veran afectados por la funcion visitar
void lista_iterar(lista_t *lista, bool (*visitar)(void *dato, void *extra), void *extra);
#endif // LISTA_H
