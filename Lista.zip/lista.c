#include "lista.h"
#include <stdlib.h>
typedef struct nodo {
	void* dato;
	struct nodo* siguiente;
	} nodo_lista_t;

typedef struct lista{
	nodo_lista_t* primero;
	nodo_lista_t* ultimo;
	size_t largo;
	} lista_t;

typedef struct lista_iter{
	lista_t* lista_apuntada;
	nodo_lista_t* actual;
	nodo_lista_t* anterior;
	} lista_iter_t;

//Crea un nuevo nodo
static nodo_lista_t* nodo_crear(void* dato, nodo_lista_t* proximo);

static nodo_lista_t* nodo_crear(void* dato, nodo_lista_t* proximo){

	nodo_lista_t* nodo_nuevo = malloc(sizeof(nodo_lista_t));
	if (nodo_nuevo){
		nodo_nuevo->dato = dato;
		nodo_nuevo->siguiente = proximo; 
		}
	return nodo_nuevo;
	}

//Actualiza el valor del primer elemento de la lista
//Pre: la lista y el nodo fueron creados
void lista_actualizar_primero(lista_t *lista, nodo_lista_t* nuevo_primero);

//Actualiza el valor del ultimo elemento de la lista
//Pre: la lista y el nodo fueron creados
void lista_actualizar_ultimo(lista_t *lista, nodo_lista_t* nuevo_ultimo);

//Analiza en caso debe insertar y lo aplica, modificando como corresponde la lista
//Pre: el iterador fue creado
void lista_iter_insertar_segun_caso(lista_iter_t *iter, nodo_lista_t* nuevo_nodo);

//Inserta un dato al principio, utilizando el iterador
//Pre: El iterador fue creado y apunta al principio de la lista
void lista_iter_insertar_al_principio(lista_iter_t *iter, nodo_lista_t *nuevo_primero);

//Inserta un nuevo elemento a la lista entre el primer y ultimo elemento de la misma
//Pre: El iterador fue creado
void lista_iter_insertar_medio(lista_iter_t *iter, nodo_lista_t *nuevo_medio);

//Inserta un dato al final, utilizando el iterador
//Pre: El iterador fue creado y apunta al final de la lista
void lista_iter_insertar_al_final(lista_iter_t *iter, nodo_lista_t *nuevo_ultimo);

//Busca en que caso tiene que borrar un elemento el iterador y lo aplica
//actualizando como se deba la lista
//Pre: el iterador fue creado
void lista_iter_borrar_casos(lista_iter_t* iter);

//El iterador borra un elemento que se encuentra al principio
//Pre: el iterador fue creado y apunta al primero
void lista_iter_borrar_primero(lista_iter_t *iter);

//El iterador borra un elemento entre el principio y el final
//Pre: el iterador fue creado
void lista_iter_borrar_medio(lista_iter_t *iter);

//El iterador borra un elemento que se encuentra al final
//Pre: el iterador fue creado y apunta al ultimo
void lista_iter_borrar_ultimo(lista_iter_t *iter);


lista_t* lista_crear(void){
	lista_t* lista_nueva = malloc(sizeof(lista_t));
	if (!lista_nueva){
		return NULL;
		}
	lista_nueva->primero = NULL;
	lista_nueva->ultimo = NULL;
	lista_nueva->largo = 0;
	return lista_nueva;
	}

size_t lista_largo(const lista_t *lista){
	return lista->largo;
	}

bool lista_esta_vacia(const lista_t *lista){
	return !lista->primero; //podria ser lista->largo
	}

void lista_actualizar_primero(lista_t *lista, nodo_lista_t* nuevo_primero){
	if (lista_esta_vacia(lista)){
		lista->ultimo = nuevo_primero;
			}
	nuevo_primero->siguiente = lista->primero;
	lista->primero = nuevo_primero;
	lista->largo++;
	}

bool lista_insertar_primero(lista_t *lista, void *dato){
	nodo_lista_t* nodo_nuevo = nodo_crear(dato,lista->primero);
	if (nodo_nuevo){
		lista_actualizar_primero(lista,nodo_nuevo);
		}
	return nodo_nuevo; 
	}

void lista_actualizar_ultimo(lista_t *lista, nodo_lista_t* nuevo_ultimo){
	if (lista_esta_vacia(lista)){
		lista->primero = nuevo_ultimo;
		}
	else{
		lista->ultimo->siguiente = nuevo_ultimo;
		
		}
	lista->ultimo = nuevo_ultimo;
	lista->largo++;
	}

bool lista_insertar_ultimo(lista_t *lista, void *dato){
	nodo_lista_t* nodo_nuevo = nodo_crear(dato,NULL);
	if (nodo_nuevo){
		lista_actualizar_ultimo(lista,nodo_nuevo);
		}
	return nodo_nuevo;
	}

void *lista_ver_primero(const lista_t *lista){
	void* primer_dato = NULL;
	if (!lista_esta_vacia(lista)){
		primer_dato = lista->primero->dato;
		}
	return primer_dato;
	}

void* lista_borrar_primero(lista_t *lista){
	void* primer_dato = NULL;
	if (!lista_esta_vacia(lista)){
		nodo_lista_t* nodo_actual = lista->primero;
		primer_dato = nodo_actual->dato;
		lista->primero = nodo_actual->siguiente;		
		free(nodo_actual);
		lista->largo--;
		}
	return primer_dato;
	}

void lista_destruir(lista_t *lista, void destruir_dato(void *)){
	
	while (!lista_esta_vacia(lista)){
		if (destruir_dato){
			destruir_dato(lista->primero->dato);
			}
		lista_borrar_primero(lista);
		}	
	free(lista);
	}

lista_iter_t* lista_iter_crear(lista_t *lista){

	lista_iter_t* lista_iterador = malloc(sizeof(lista_iter_t));
	if (lista_iterador){
		lista_iterador->lista_apuntada = lista;
		lista_iterador->actual = lista->primero;
		lista_iterador->anterior = NULL;
		}
	return lista_iterador;
	}

void lista_iter_destruir(lista_iter_t *iter){
	free(iter);	
	}

void *lista_iter_ver_actual(const lista_iter_t *iter){
	void* dato_actual = NULL;
	if (iter->actual){
		dato_actual = iter->actual->dato;
		}
	return dato_actual;
	}

bool lista_iter_avanzar(lista_iter_t *iter){
	bool iterador_avanzo = false;
	if (iter->actual){
		nodo_lista_t* actual = iter->actual;
		iter->anterior = actual;
		iter->actual = actual->siguiente;
		iterador_avanzo = true;
		}
	else if (iter->lista_apuntada->primero && (!lista_iter_al_final(iter))){
		iter->actual = iter->lista_apuntada->primero;
		iter->anterior = NULL;
		iterador_avanzo = true;
		}
	return iterador_avanzo;
	}

void lista_iter_insertar_al_principio(lista_iter_t *iter, nodo_lista_t *nuevo_primero){
	if (iter->actual == NULL){ //lista vacia
		iter->lista_apuntada->ultimo = nuevo_primero;
		}
	else { //estoy parado en el primer lugar
		nuevo_primero->siguiente = iter->actual;
		}
	iter->lista_apuntada->primero = nuevo_primero;
	}

void lista_iter_insertar_al_final(lista_iter_t *iter, nodo_lista_t *nuevo_ultimo){
	iter->lista_apuntada->ultimo->siguiente = nuevo_ultimo;
	iter->lista_apuntada->ultimo = nuevo_ultimo;
	iter->lista_apuntada->ultimo->siguiente = NULL; //si no apuntara al nodo anterior
	}

void lista_iter_insertar_medio(lista_iter_t *iter, nodo_lista_t *nuevo_medio){
	nodo_lista_t* nodo_actual = iter->actual;
	nuevo_medio->siguiente = nodo_actual;
	iter->anterior->siguiente = nuevo_medio;
	}

void lista_iter_insertar_segun_caso(lista_iter_t *iter, nodo_lista_t* nuevo_nodo){
	if (iter->anterior == NULL){
		lista_iter_insertar_al_principio(iter,nuevo_nodo);
		}
	else if (iter->anterior && (iter->actual == NULL)){ //parado al final
		lista_iter_insertar_al_final(iter,nuevo_nodo);
		}
	else{ //parado entre el primero y el ultimo
		lista_iter_insertar_medio(iter,nuevo_nodo);
		}
	//en todo caso
	iter->actual = nuevo_nodo;
	iter->lista_apuntada->largo++;
	}

bool lista_iter_insertar(lista_iter_t *iter, void *dato){
	
	bool insercion = false;
	nodo_lista_t* nuevo_nodo = nodo_crear(dato,iter->actual);
	if (nuevo_nodo){
		insercion = true;
		lista_iter_insertar_segun_caso(iter,nuevo_nodo);	
		}
	return insercion;
	}

void lista_iter_borrar_ultimo(lista_iter_t *iter){
	iter->actual = NULL;
	iter->lista_apuntada->ultimo = iter->anterior;
	iter->lista_apuntada->ultimo->siguiente = NULL;
	}

void lista_iter_borrar_primero(lista_iter_t *iter){
	iter->actual = iter->actual->siguiente;
	iter->lista_apuntada->primero = iter->actual;
	}

void lista_iter_borrar_medio(lista_iter_t *iter){
	iter->anterior->siguiente = iter->actual->siguiente;
	iter->actual = iter->anterior->siguiente;
	}


void lista_iter_borrar_casos(lista_iter_t* iter){
	if ((iter->anterior) && (iter->actual->siguiente == NULL)){ //estoy parado al final
		lista_iter_borrar_ultimo(iter);
		}

	else if (iter->anterior){ // && iter->act->sig != NULL estoy en el medio
		lista_iter_borrar_medio(iter);
		}
		
	else{ //Existe actual pero no anterior, entonces estoy en el primer elemento
		lista_iter_borrar_primero(iter);
		}
	}		
void *lista_iter_borrar(lista_iter_t *iter){
	void* dato_eliminado = NULL;
	if (iter->actual){
		nodo_lista_t* nodo_actual = iter->actual;
		dato_eliminado = nodo_actual->dato;
		lista_iter_borrar_casos(iter);
		free(nodo_actual);
		iter->lista_apuntada->largo--;
		}
	return dato_eliminado;
	}
bool lista_iter_al_final(const lista_iter_t *iter){
	bool al_final = false;
	if ((iter->actual) == NULL){
		al_final = true;
		}	
	return al_final;
	}

void lista_iterar(lista_t *lista, bool (*visitar)(void *dato, void *extra), void *extra){
	nodo_lista_t* nodo_actual = lista->primero;
	while(nodo_actual){
		bool resultado = visitar(nodo_actual->dato,extra);
		if (resultado){
			nodo_actual = nodo_actual->siguiente;
			continue;
			}
		break;
		}
	}
