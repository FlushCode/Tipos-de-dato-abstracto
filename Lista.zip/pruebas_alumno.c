#include "lista.h"
#include "testing.h"
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>

void pruebas_lista_iter_interno(void);
void pruebas_lista_vacia(void);
void pruebas_lista_unico_elemento(void);
void pruebas_lista_varios_elementos(void);
void pruebas_lista_invertir(void);
void pruebas_lista_alumno(void){
	pruebas_lista_vacia();
	pruebas_lista_unico_elemento();
	pruebas_lista_varios_elementos();
    pruebas_lista_invertir();
    pruebas_lista_iter_interno();
	}

//Pre: Debe recibir un arreglo de punteros genericos
//Post: Lo completa con punteros a enteros ordenados que
//hacen referencia desde 0 hasta limite-1
void llenar_arreglo_con_enteros(void** arreglo, size_t limite);

void pruebas_lista_vacia(void){
	puts("\n*** PRUEBAS LISTA VACIA (PRIMITIVAS) ***\n");

	lista_t* lista_vacia = lista_crear();
	bool esta_vacia = lista_esta_vacia(lista_vacia);
	print_test("Al crearla inicialmente esta vacia",esta_vacia == true);
	size_t largo_lista = lista_largo(lista_vacia);
	print_test("Su largo es 0",largo_lista == 0);
	void* primer_elemento = lista_ver_primero(lista_vacia);
	print_test("Preguntar por su primer elemento devuelve NULL",primer_elemento == NULL); 
	largo_lista = lista_largo(lista_vacia);
	print_test("Su largo es 0 luego de preguntar por el primer elemento",largo_lista == 0);
	void* primer_elemento_borrado = lista_borrar_primero(lista_vacia);
	print_test("Al intentar borrar el primer elemento devuelve NULL",primer_elemento_borrado == NULL);
	primer_elemento = lista_ver_primero(lista_vacia);
	print_test("Su primer elemento es NULL luego de intentar borrar el primero",primer_elemento == NULL);
	largo_lista = lista_largo(lista_vacia);
	print_test("Su largo es 0 luego de intentar borrar el primero",largo_lista == 0);
	esta_vacia = lista_esta_vacia(lista_vacia);
	print_test("Sigue estando vacia luego de intentar borrar un primer elemento que no existe",esta_vacia == true);
	
	puts("\n*** PRUEBAS LISTA VACIA (ITERADOR) ***\n");
	
	lista_iter_t* iterador_lista_vacia = lista_iter_crear(lista_vacia);
	void* apuntado_actual = lista_iter_ver_actual(iterador_lista_vacia);
	bool al_final = lista_iter_al_final(iterador_lista_vacia);
	print_test("Inicialmente, el iterador se encuentra se encuentra al final",al_final == true);
	//Lo pense como si el iterador no esta ni al principio ni en el fin, no hay un nodo anterior
	print_test("El iterador inicialmente apunta a NULL",apuntado_actual == NULL);
	bool iterador_avanzara;
	bool iterador_avanzo = false;	
	for (size_t i = 0; i < 10; i++){
		iterador_avanzara= lista_iter_avanzar(iterador_lista_vacia);
		if (iterador_avanzara){iterador_avanzo = true;}
		}
	
	print_test("Al intentar avanzar el iterador no avanza nunca",iterador_avanzo == false);
	void * borrar_con_iterador = lista_iter_borrar(iterador_lista_vacia);
	print_test("Al intentar borrar con el iterador devuelve NULL", borrar_con_iterador == NULL);
	al_final = lista_iter_al_final(iterador_lista_vacia);
	print_test("El iterador sigue encontrandose al final",al_final == true);

	puts("*** LUEGO DE QUE INTERACTUE EL ITERADOR CON ELLA ***");
	primer_elemento = lista_ver_primero(lista_vacia);
	print_test("Su primer elemento es NULL",primer_elemento == NULL);
	largo_lista = lista_largo(lista_vacia);
	print_test("Su largo es 0",largo_lista == 0);
	esta_vacia = lista_esta_vacia(lista_vacia);
	print_test("Sigue estando vacia",esta_vacia == true);

	lista_iter_destruir(iterador_lista_vacia);
	lista_destruir(lista_vacia,NULL);
	}

void pruebas_lista_unico_elemento(void){
	puts("\n*** PRUEBAS CON UN UNICO ELEMENTO (PRIMITIVAS) ***\n");
	lista_t* nueva_lista = lista_crear();
	int a = 1;
	int *d = &a;
	bool insertar_al_principio = lista_insertar_primero(nueva_lista,(void*)d);
	print_test("Se ha insertado el entero 3 en la lista correctamente",insertar_al_principio == true);
	void* primer_elemento = lista_ver_primero(nueva_lista);
	print_test("El primer elemento de la lista es el entero 3",primer_elemento == (void*)d);
	size_t largo = lista_largo(nueva_lista);
	print_test("El largo de la lista es 1 luego de insertar_primero",largo == 1);
	bool no_tiene_elementos = lista_esta_vacia(nueva_lista);
	print_test("No esta vacia luego de insertar_primero",no_tiene_elementos == false);
	void* primero_eliminado = lista_borrar_primero(nueva_lista);
	print_test("El primero eliminado es 3",primero_eliminado == (void*)d);
	no_tiene_elementos = lista_esta_vacia(nueva_lista);
	print_test("Esta vacia luego de borrar_primero",no_tiene_elementos == true);
	largo = lista_largo(nueva_lista);
	print_test("El largo de la lista es 0 luego de borrar_primero",largo == 0);
	primer_elemento = lista_ver_primero(nueva_lista);
	print_test("El primer elemento de la lista es NULL",primer_elemento == NULL);
	
	bool inserto_al_final = lista_insertar_ultimo(nueva_lista,(void*)d);
	print_test("Se ha insertado al final con exito",inserto_al_final == true);
	primer_elemento = lista_ver_primero(nueva_lista);
	print_test("El primer elemento de la lista es el entero 3",primer_elemento == (void*)d);
	largo = lista_largo(nueva_lista);
	print_test("El largo de la lista es 1 luego de insertar_ultimo",largo == 1);
	no_tiene_elementos = lista_esta_vacia(nueva_lista);
	print_test("No esta vacia luego de insertar_ultimo",no_tiene_elementos == false);
	primero_eliminado = lista_borrar_primero(nueva_lista);
	print_test("El primero eliminado es 3",primero_eliminado == (void*)d);
	no_tiene_elementos = lista_esta_vacia(nueva_lista);
	print_test("Esta vacia luego de borrar_primero",no_tiene_elementos == true);
	largo = lista_largo(nueva_lista);
	print_test("El largo de la lista es 0 luego de borrar_primero",largo == 0);
	primer_elemento = lista_ver_primero(nueva_lista);
	print_test("El primer elemento de la lista es NULL",primer_elemento == NULL);
	
	
	puts("\n*** PRUEBAS CON UN UNICO ELEMENTO (ITERADOR) ***\n");

	lista_iter_t* iter = lista_iter_crear(nueva_lista);
	bool insertara = lista_iter_insertar(iter,(void*)d);
	print_test("Se ha insertado con exito el entero 3",insertara == true);
	bool al_final = lista_iter_al_final(iter);
	print_test("El iterador no se encuentra al final de la lista",al_final == false);
	void* dato_actual = lista_iter_ver_actual(iter);
	print_test("El dato actual es 3",dato_actual == (void*)d);
	primer_elemento = lista_ver_primero(nueva_lista);
	print_test("El primer elemento de la lista es el entero 3",primer_elemento == (void*)d);
	largo = lista_largo(nueva_lista);
	print_test("El largo de la lista es 1 luego de iter_insertar",largo == 1);
	no_tiene_elementos = lista_esta_vacia(nueva_lista);
	print_test("No esta vacia luego de iter_insertar",no_tiene_elementos == false);
	void* borrar_primero = lista_borrar_primero(nueva_lista);
	print_test("Se borro el elemento con borrar_primero",borrar_primero == (void*)d);
	dato_actual = lista_ver_primero(nueva_lista);
	print_test("El dato actual debe ser NULL",dato_actual == NULL);
	largo = lista_largo(nueva_lista);
	print_test("El largo de la lista es 0 luego de borrar_primero",largo == 0);
	lista_iter_destruir(iter);
	lista_iter_t* iter2 = lista_iter_crear(nueva_lista);
	insertara = lista_iter_insertar(iter2,(void*)d);
	print_test("Se ha insertado con exito el entero 3",insertara == true);
	borrar_primero = lista_iter_borrar(iter2);
	print_test("Se borro el elemento con iter_borrar",borrar_primero == (void*)d);
	al_final = lista_iter_al_final(iter2);
	print_test("El iterador no se encuentra al final de lalista",al_final == true);
	primer_elemento = lista_ver_primero(nueva_lista);
	print_test("El primer elemento de la lista es NULL",primer_elemento == NULL);
	largo = lista_largo(nueva_lista);
	print_test("El largo de la lista es 0 luego de iter_borrar",largo == 0);
	no_tiene_elementos = lista_esta_vacia(nueva_lista);
	print_test("Esta vacia luego de iter_borrar",no_tiene_elementos == true);
	lista_iter_destruir(iter2);
	lista_destruir(nueva_lista,NULL);
	}

void llenar_arreglo_con_enteros(void** arreglo, size_t limite);

void llenar_arreglo_con_enteros(void** vArray, size_t limite){
	int j;
	for (j = 0; j < limite; j++){
		int* pInt = malloc(sizeof(int));
		*pInt = j;
		vArray[j] = (void*)pInt;
		}
	}
    
	
void pruebas_lista_varios_elementos(void){
	puts("\n*** PRUEBA VARIOS ELEMENTOS (PRIMITIVAS) ***\n");
	lista_t* lista_pequena = lista_crear();
	const size_t elementos_enlistar = 10; //Solo admite pares
	void** vArreglo = malloc(elementos_enlistar*sizeof(void*));
	size_t i;
	llenar_arreglo_con_enteros(vArreglo, elementos_enlistar);	
	size_t fallas_al_actualizar_largo = 0;
	for (i = 0; i < elementos_enlistar; i++){
		lista_insertar_ultimo(lista_pequena,vArreglo[i]);
		if (lista_largo(lista_pequena) != i+1){
			fallas_al_actualizar_largo++;
			}
		}
	print_test("Los largos se actualizaron correctamente luego de insertar varios elementos",fallas_al_actualizar_largo == 0);
	size_t fallas_al_ver_primero = 0;
	size_t fallas_al_comparar_borrado = 0;
	for (i = 0; i < elementos_enlistar; i++){
		void* primero = lista_ver_primero(lista_pequena);
		if (primero != vArreglo[i]){
			fallas_al_ver_primero++;
			}
		void* borrar_primero = lista_borrar_primero(lista_pequena);
		if (borrar_primero != vArreglo[i]){
			fallas_al_comparar_borrado++;
			}
		free(borrar_primero);
		}
	print_test("Borrar cada elemento devuelve uno que coincide con el que se inserto",fallas_al_comparar_borrado == 0);
	print_test("Los primeros elementos de la lista fueron correctos en cada iteracion",fallas_al_ver_primero == 0);
	
	llenar_arreglo_con_enteros(vArreglo, elementos_enlistar);
	
	for (i = 0; i < elementos_enlistar/2; i++){ //va a insertar al final hasta el elemento 5
		lista_insertar_ultimo(lista_pequena,vArreglo[i]);
		
		}
	for (i = elementos_enlistar/2; i < elementos_enlistar; i++){ //va a insertar al principio hasta el elemento 10
		lista_insertar_primero(lista_pequena,vArreglo[i]);
		
		}
	//El arreglo deberia ser {9,8,7,6,5,0,1,2,3,4}
	
	for (i = 0; i < elementos_enlistar; i++){
		void* primero = lista_ver_primero(lista_pequena);
		if (i <= (elementos_enlistar/2)-1){
			if (primero != vArreglo[elementos_enlistar-i-1]){
				
				fallas_al_ver_primero++;
				}
			}
		else { // son elementos de la otra mitad
			if (primero != vArreglo[i-elementos_enlistar/2]){
				fallas_al_ver_primero++;
				}
			}
		void* borrar_primero = lista_borrar_primero(lista_pequena);
		if (i <= (elementos_enlistar/2)-1){
			if (borrar_primero != vArreglo[elementos_enlistar-i-1]){
				
				fallas_al_comparar_borrado++;
				}
			}
		else { // son elementos de la otra mitad
			if (borrar_primero != vArreglo[i-elementos_enlistar/2]){
				fallas_al_comparar_borrado++;
				}
			}
		free(borrar_primero);
		}
	print_test("Se inserto de forma desordenada y los primeros mantienen coherencia",fallas_al_ver_primero == 0);
	print_test("Idem al ir borrando los elementos y compararlos",fallas_al_comparar_borrado == 0);
	
	bool esta_vacia = lista_esta_vacia(lista_pequena);
	print_test("La lista esta vacia luego de borrar los elementos del vector dinamico",esta_vacia == true);

	puts("\n*** PRUEBAS DE VARIOS ELEMENTOS (ITERADOR) ***\n");

	llenar_arreglo_con_enteros(vArreglo,elementos_enlistar);
	for (i = 0; i < elementos_enlistar; i++){
		lista_insertar_ultimo(lista_pequena,vArreglo[i]);
		}
	lista_iter_t* iter = lista_iter_crear(lista_pequena);
	size_t iterador_no_pudo_avanzar = 0;
	size_t no_coincide_iter_actual = 0;
	for (i = 0; i < elementos_enlistar; i++){
		void* ver_actual = lista_iter_ver_actual(iter);
		if (ver_actual != vArreglo[i]){
			no_coincide_iter_actual++;
			}
		bool iter_avanza = lista_iter_avanzar(iter);
		if (!iter_avanza){iterador_no_pudo_avanzar++;}
		
		}
	print_test("El iterador avanzo sin problemas",iterador_no_pudo_avanzar == 0);
	print_test("Iter_actual devuelve el elemento de la misma posicion en el arreglo",no_coincide_iter_actual == 0);
	bool iter_al_final = lista_iter_al_final(iter);
	print_test("El iterador se encuentra al final",iter_al_final == true);
	bool iter_avanza = lista_iter_avanzar(iter);
	iter_al_final = lista_iter_al_final(iter);
	void* ver_actual = lista_iter_ver_actual(iter);
	print_test("El iterador no pudo avanzar, se encuentra al final y apunta a NULL",(iter_avanza == false) &&  (iter_al_final == true) && (ver_actual == NULL));
    lista_iter_destruir(iter);	
	lista_destruir(lista_pequena,free);    
    free(vArreglo);
	}

void pruebas_lista_invertir(void){
    puts("\n***PRUEBA DE INVERTIR UNA LISTA UTILIZANDO UN ITERADOR***\n");
    
    lista_t* lista_pequena2 = lista_crear();
    
    const size_t elementos_enlistar = 10;
    void** vArreglo2 = malloc(elementos_enlistar*sizeof(void*));
    llenar_arreglo_con_enteros(vArreglo2,elementos_enlistar);
    size_t k,i;
    for (k = 0; k < elementos_enlistar; k++){
        lista_insertar_ultimo(lista_pequena2,vArreglo2[k]);
        }
    
    size_t pos_insertar = 1;
	for (i = 0; i < elementos_enlistar; i++){
        
        lista_iter_t* nuevo_iterador = lista_iter_crear(lista_pequena2);
        void* primero = lista_iter_borrar(nuevo_iterador);
        
        for (k = 0; k < elementos_enlistar-pos_insertar; k++){
            lista_iter_avanzar(nuevo_iterador);
            }
        lista_iter_insertar(nuevo_iterador,primero);
        lista_iter_destruir(nuevo_iterador);
        pos_insertar++;
        }
    lista_iter_t* iter = lista_iter_crear(lista_pequena2);
    bool lista_revirtio = true;
    for (k = 0; k < elementos_enlistar; k++){
            void* primero = lista_iter_ver_actual(iter);
            if (primero != vArreglo2[elementos_enlistar-k-1]){
                lista_revirtio = false;
                break;
                }
            lista_iter_avanzar(iter);   
        }
    
    print_test("La lista se invirtio exitosamente",lista_revirtio == true);
    size_t largo = lista_largo(lista_pequena2);
    print_test("Su largo se conservo",largo == elementos_enlistar);
    lista_iter_destruir(iter);
    lista_destruir(lista_pequena2,free);
	free(vArreglo2);
    }
bool algun_par(void* dato, void* resultado){
	bool* hay_par = resultado;
	int* actual = dato;
	if (*actual % 2 == 0){
		*hay_par = true;
		return false;
		}
	*hay_par = false;
	return true;
	}


bool multiplicar_por_n(void* dato, void* resultado){
    int* factor = resultado;
    int* actual = dato;
    *actual*=*factor;
    return true;
    }
    
void pruebas_lista_iter_interno(void){
    puts("\n***PRUEBAS ITERADOR INTERNO (ALGUN PAR)***\n");
    lista_t* lista_impares = lista_crear(); 
    const size_t cantidad_elementos = 7;
    int k;
    for (k = 0; k < cantidad_elementos; k++){
        
        int* pInt = malloc(sizeof(int));
        if (k%2 == 0){*pInt = k+1;}
        else{*pInt = k;}
        lista_insertar_primero(lista_impares,(void*)pInt);
        }
    
    bool resultado_impares = true;
	lista_iterar(lista_impares,algun_par,&resultado_impares);
    print_test("Buscar un par en la lista de impares devuelve que no hay ninguno",resultado_impares == false);
    
    const size_t pos_random = 7; //posicion cualquiera en donde insertare un par enn la lista
    int* pPar = malloc(sizeof(int));
    *pPar = 8;
    lista_iter_t* iter = lista_iter_crear(lista_impares);
    for (k = 0; k < pos_random; k++){  
        lista_iter_avanzar(iter);
        }
    lista_iter_insertar(iter,(void*)pPar);
    lista_iter_destruir(iter);
    
    bool resultado_un_par = false;
	lista_iterar(lista_impares,algun_par,&resultado_un_par);
    print_test("Luego de insertar un par, devuelve que si hay uno",resultado_un_par == true);
    lista_destruir(lista_impares,free);
    
    puts("\n***Prueba de la funcion multiplicar por 2***\n");
    int antes[10] = {0,1,2,3,4,5,6,7,8,9};

    lista_t* lista_enteros = lista_crear();
    
    const size_t elementos_enlistar = 10;
    
    for (k = 0; k < elementos_enlistar; k++){
        int* pInt = malloc(sizeof(int));
        *pInt = k;
        lista_insertar_ultimo(lista_enteros,(void*)pInt);
        }
    int n = 2;
    int* factor = &n;
    lista_iterar(lista_enteros,multiplicar_por_n,(void*)factor);
    iter = lista_iter_crear(lista_enteros);
    bool multiplicar_fallo = false;
    
    for (k = 0; (!lista_iter_al_final(iter)) && (multiplicar_fallo == false); k++){
        void* actual = lista_iter_ver_actual(iter);
        if ((*(int*)actual) != (antes[k]*n)){
            multiplicar_fallo = true;
            }
        lista_iter_avanzar(iter);
        }
    print_test("Se ha multiplicado satisfactoriamente a cada elemento de la lista por un factor determinado",multiplicar_fallo == false);
    lista_iter_destruir(iter);
    lista_destruir(lista_enteros,free);
    }
