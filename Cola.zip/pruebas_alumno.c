#include "cola.h"
#include "testing.h"
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>


void pruebas_cola_vacia();
void pruebas_cola_null();
void pruebas_un_elemento();
void pruebas_de_volumen();
void pruebas_de_volumen2();
void prueba_cola_de_colas();

void pruebas_cola_alumno(){
	pruebas_cola_vacia();
	pruebas_cola_null();
	pruebas_un_elemento();
	pruebas_de_volumen();
	pruebas_de_volumen2();
	prueba_cola_de_colas();
	}

void pruebas_cola_vacia(){
	puts("***PRUEBAS COLA VACIA***");
	cola_t* cola_vacia = cola_crear();
	bool estado_cola = cola_esta_vacia(cola_vacia);
	print_test("La cola vacia al chequear es vacia",estado_cola == true);
	void* primero = cola_ver_primero(cola_vacia);
	print_test("El primer elemento de la cola vacia es NULL",primero == NULL);
	void* elemento = cola_desencolar(cola_vacia);
	print_test("La cola vacia al desencolar devuelve NULL", elemento == NULL);
	estado_cola = cola_esta_vacia(cola_vacia);
	print_test("La cola vacia sigue estando vacia",estado_cola == true);
	primero = cola_ver_primero(cola_vacia);
	print_test("Su tope sigue siendo vacio",primero == NULL);
	cola_destruir(cola_vacia,NULL);
	}

void pruebas_un_elemento(){
	puts("****PRUEBAS UN ELEMENTO****");
	cola_t* cola_unico_elemento = cola_crear();
	int z = 8;
	int* x = &z;
	cola_encolar(cola_unico_elemento,(void*)x);
	bool cola_es_vacia = cola_esta_vacia(cola_unico_elemento);
	print_test("La cola con un elemento no esta vacia",cola_es_vacia == false);
	void* primero = cola_ver_primero(cola_unico_elemento);
	print_test("El primer elemento coincide con el elemento encolado",primero == (void*)x);
	void* elemento = cola_desencolar(cola_unico_elemento);
	print_test("El elemento desencolado coincide con el encolado",elemento == (void*)x);
	bool cola_vacia = cola_esta_vacia(cola_unico_elemento);
	print_test("La cola esta vacia luego de desencolar el ultimo elemento", cola_vacia == true);
	cola_destruir(cola_unico_elemento,NULL);
	}
	
	

void pruebas_cola_null(){
	puts("***PRUEBAS COLA ENCOLANDO NULL***");
	cola_t* cola_null = cola_crear();
	cola_encolar(cola_null,NULL);
	bool estado_cola_null = cola_esta_vacia(cola_null);
	print_test("Luego de apilar NULL, el estado de la cola es no vacio", estado_cola_null == false);
	void* elemento = cola_ver_primero(cola_null);	
	print_test("Luego de encolar el primero es NULL",elemento == NULL);
	void* elemento_desencolado = cola_desencolar(cola_null);
	print_test("Luego hago desencolar y me devuelve el elemento NULL", elemento_desencolado == NULL);
	bool estado_cola_null_desencolar = cola_esta_vacia(cola_null);
	print_test("Al desencolar null, la cola esta vacia",estado_cola_null_desencolar == true);
	cola_destruir(cola_null,NULL);

	}
void pruebas_de_volumen(){

	puts("***PRUEBAS DE VOLUMEN 1***");
	cola_t* cola_nueva = cola_crear();
	const size_t tam_prueba = 312;
	int i;
	for (i = 0; i < tam_prueba; i++){
		char* dato_nuevo = malloc(sizeof(char));
		cola_encolar(cola_nueva,dato_nuevo);
		}
	bool cola_no_esta_vacia = cola_esta_vacia(cola_nueva);
	print_test("La cola de muchos elementos no esta vacia",cola_no_esta_vacia == false);
	cola_destruir(cola_nueva,free);
	print_test("Los elementos fueron destruidos mediante cola_destruir",true == true);
	}

void pruebas_de_volumen2(){
	puts("***PRUEBAS DE VOLUMEN 2***");
	cola_t* cola_nueva = cola_crear();
	const size_t tam_prueba = 218;
	int* enteros = malloc(tam_prueba*sizeof(int));
	int j;
	for (j = 0; j < tam_prueba; j++){
		enteros[j] = j;
		cola_encolar(cola_nueva,(void*)&enteros[j]);
		}
	size_t desencolados_incorrectos = 0;
	for (j = 0; j < tam_prueba; j++){
		void* elemento_desencolado = cola_desencolar(cola_nueva);
		if (elemento_desencolado != (void*)&enteros[j]){
			desencolados_incorrectos++;
			}
		}
	print_test("Los elementos desencolados coinciden con los encolados previamente", desencolados_incorrectos == 0);
	cola_destruir(cola_nueva,NULL);	
	free(enteros);
	} 
void destruir_cola_y_valores(void* dato);

void destruir_cola_y_valores(void* dato){
	cola_t* cola = dato;
	cola_destruir(cola,free);
	}
void prueba_cola_de_colas(){
	puts("***PRUEBA COLA QUE ENCOLA COLAS CON DATOS EN MEMORIA DINAMICA***");	
	cola_t* cola_de_procesos = cola_crear();
	unsigned int i,j;
	const unsigned int elementos_por_cola = 103;
	const size_t cantidad_colas = 105;
	int encolaciones_incorrectas = 0;
	for (i = 0; i < cantidad_colas; i++){
		cola_t* cola_a_encolar = cola_crear();
		for (j = 0; j < elementos_por_cola; j++){
			char* pChar = malloc(sizeof(char));
			bool ultimo_dato_encolado = cola_encolar(cola_a_encolar,pChar);
			if (!ultimo_dato_encolado){
				encolaciones_incorrectas++;
				}
			}
		bool ultima_cola_encolada = cola_encolar(cola_de_procesos,(void*)cola_a_encolar);
		if (!ultima_cola_encolada){
			encolaciones_incorrectas++;
			}
		}
	print_test("Se encolo todo correctamente al fabricar la cola de procesos, sus colas y sus datos",encolaciones_incorrectas == 0);
	cola_destruir(cola_de_procesos,destruir_cola_y_valores);
	}

