#include "pila.h"
#include <stdlib.h>

#define DOBLAR 2
#define TAM_INICIAL 20

/*
 Pre: Debe recibir un puntero

 Post: Devuelve True si al puntero se le asigno NULL
       Caso contrario, False
*/
bool puntero_es_nulo(void * puntero);

/*
  Pre:  Recibe un puntero del tipo pila_t*

  Post: Devuelve true si el largo de la pila esta por
  	sobrepasar al tamano de la misma, caso contrario, false
*/
bool pila_saturara(pila_t* pila);

/*
  Pre:  Recibe un puntero del tipo pila_t*

  Post: Si el largo de la pila es 1/4 del tamano
  	de la pila (y el tamano es distinto de TAM_INICIAL)
  	devuelve True
*/
bool pila_reducio_largo(pila_t* pila);

/*
  Pre: Recibe un puntero del tipo pila_t*

  Post: Inicializa a valores fijos a los miembros de 
  	la estructura, devuelve la misma pila si se
	inicializo con exito, caso contrario, NULL
*/
pila_t* pila_inicializar(pila_t* pila);

/*
  Pre: Recibe un puntero a una pila y un tam_nuevo del
	tipo size_t

  Post: Devuelve true si se pudo redimensionar la pila 
	a tam_nuevo, caso contrario, false
*/
bool pila_redimensionar_datos(pila_t* pila, size_t tam_nuevo);

/* Pre: Recibe un puntero a una pila
   
   Post: Reduce su tamano 
*/
void pila_reducir_tamano(pila_t* pila);
/* Definición del struct pila proporcionado por la cátedra.
 */
bool pila_ampliar_tamano(pila_t* pila);

struct pila {
    void **datos;
    size_t largo; // N.� de elementos guardados en la pila
    size_t tam; //Capacidad de �datos� (memoria reservada).
};

/* *****************************************************************
 *                    PRIMITIVAS DE LA PILA
 * *****************************************************************/
pila_t* pila_crear(void){
	
	pila_t* pila = malloc(sizeof(pila_t));
	
	if (puntero_es_nulo(pila)){
		return NULL;
	}

	pila_t* pila_inicializada = pila_inicializar(pila);
	return pila_inicializada;
}

void pila_destruir(pila_t *pila){
	free(pila->datos);
	free(pila);
}

bool pila_esta_vacia(const pila_t *pila){
	
	return !(pila->largo);
}
void* pila_ver_tope(const pila_t *pila){
	
	if (!pila_esta_vacia(pila)){
		return pila->datos[pila->largo];
	}
	return NULL;
}
bool pila_apilar(pila_t *pila, void* valor){
	if (pila_saturara(pila)){
		if (!pila_ampliar_tamano(pila)){
			return false;
		}
	}
	pila->largo++;
	pila->datos[pila->largo] = valor; 
	
	return true;
}
void* pila_desapilar(pila_t *pila){
	
	if (!pila_esta_vacia(pila)){
		
		void* dato;
		dato = pila->datos[pila->largo];
		pila->largo--;
		if (pila_reducio_largo(pila)){
			pila_reducir_tamano(pila);
			}
		return dato;		
	}
	
	return NULL;
}




/* *****************************************************************
 *                    FUNCIONES EXTRA
 * *****************************************************************/

 
 bool puntero_es_nulo(void * puntero){
 	
 	if (puntero == NULL){
 		return true;
	 }
	 return false;
 }
 
 pila_t* pila_inicializar(pila_t* pila){
 	
	size_t largo_inicial = 0; 
	
	pila->largo = largo_inicial;
	pila->datos = malloc(TAM_INICIAL*(sizeof(void*)));
	if (puntero_es_nulo(pila->datos)){
		return NULL;
	}
	pila->tam = (size_t)TAM_INICIAL;
	
	return pila;
 }
 
 bool pila_saturara(pila_t* pila){
 	if ( ((pila->largo) + 1) == (pila->tam) ){
 		return true;
	 }
	 return false;
 }

 bool pila_reducio_largo(pila_t* pila){
 	
	float largo_actual = (float)(pila->largo);
	float tamano_actual = (float)(pila->tam);
	float referencia_comparar = (float)1/4*(tamano_actual);
	if ( ((int)tamano_actual > (int)TAM_INICIAL) && (largo_actual == (int)referencia_comparar) ){
		
		return true;
	}
	
	return false;
	
 }

 bool pila_redimensionar_datos(pila_t* pila, size_t nuevo_tam){

 	void* datos_nuevo = realloc(pila->datos,nuevo_tam*sizeof(void*));
 	
 	if (puntero_es_nulo(datos_nuevo)){
 		return false;
	 }
	 
	 pila->datos = datos_nuevo;
	 pila->tam = nuevo_tam;

	 return true;	 
 }
 
 void pila_reducir_tamano(pila_t* pila){
	const float desdoblar_pila = 1.0/DOBLAR;
	float nuevo_tam = (desdoblar_pila * (float)pila->tam); 
	pila_redimensionar_datos(pila,(size_t)nuevo_tam);
 }
		
 bool pila_ampliar_tamano(pila_t* pila){
	
	size_t tam_doble = DOBLAR*pila->tam;		
	if (!pila_redimensionar_datos(pila,tam_doble)){
		return false;
	}
	return true;
	}
