#include "pila.h"
#include "testing.h"
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>

#define TAM_PRUEBA_ARREGLO 1000

struct pila {
    void **datos;
    size_t largo; // N.º de elementos guardados en la pila
    size_t tam; //Capacidad de datos (memoria reservada).
};

void pruebas_pila_vacia();
void pruebas_pila_unico_elemento();
void prueba_apilar_null();
void prueba_muchos_elementos();

/* ******************************************************************
 *                   PRUEBAS UNITARIAS ALUMNO
 * *****************************************************************/

void pruebas_pila_alumno() {

	prueba_apilar_null();
	pruebas_pila_vacia();
	pruebas_pila_unico_elemento();
	prueba_muchos_elementos();
	
}



void pruebas_pila_vacia(){
	printf("\n***INICIO DE PRUEBAS CON UNA PILA VACIA***/\n");
	pila_t* pila_vacia = pila_crear();
	void* tope_pila_vacia = pila_ver_tope(pila_vacia);
	print_test("El tope de la pila es NULL",tope_pila_vacia == NULL);
	bool estado_pila_vacia = pila_esta_vacia(pila_vacia);
	print_test("El estado de la pila es vacia",estado_pila_vacia == true);
	void* desapilar_pila_vacia = pila_desapilar(pila_vacia);
	print_test("Desapilar devuelve NULL",desapilar_pila_vacia == NULL);
	estado_pila_vacia = pila_esta_vacia(pila_vacia);
	print_test("El estado de la pila es vacia luego de intentar desapilar",estado_pila_vacia == true);
	pila_destruir(pila_vacia);
	
}
void pruebas_pila_unico_elemento(){
	
	
	printf("\n***INICIO DE PRUEBAS CON UNA PILA DE UN UNICO ELEMENTO EN MEMORIA DINAMICA***/\n");
	pila_t* pila_un_elemento = pila_crear();
	int* x = malloc(sizeof(int));
	if (x == NULL){
		return;
		}
	*x = 1;
	bool apilar;
	apilar = pila_apilar(pila_un_elemento,&x);
	print_test("Se pudo apilar el entero 1", apilar == true);
	void* tope_un_elemento = pila_ver_tope(pila_un_elemento);
	print_test("El tope de la pila es el entero 1", tope_un_elemento == &x);	
	bool pila_vacia = pila_esta_vacia(pila_un_elemento);
	print_test("La pila no esta vacia luego de apilar el unico elemento",pila_vacia == false);
	void* elemento_desapilado = pila_desapilar(pila_un_elemento);
	print_test("El elemento desapilado es el entero 1",elemento_desapilado == &x);
	pila_vacia = pila_esta_vacia(pila_un_elemento);
	print_test("La pila ha quedado vacia luego de desapilar el unico elemento",pila_vacia == true);
	free(x);
	pila_destruir(pila_un_elemento);
	
}

void prueba_apilar_null() {
	
	printf("\n***INICIO DE PRUEBAS APILANDO EL ELEMENTO NULO***/\n");
	pila_t* pila = pila_crear();
	bool apilar;
	apilar = pila_apilar(pila,NULL);
	print_test("La pila ha apilado el valor NULL exitosamente",apilar == true);
	void * tope = pila_ver_tope(pila);
	print_test("El tope de la pila es NULL",tope == NULL);
	bool pila_vacia = pila_esta_vacia(pila);
	print_test("La pila con el elemento NULL no esta vacia",pila_vacia == false);
	void* elemento_desapilado = pila_desapilar(pila);
	print_test("El elemento desapilado es NULL", elemento_desapilado == NULL);
	pila_vacia = pila_esta_vacia(pila);
	print_test("La pila tras desapilar el elemento NULL esta vacia",pila_vacia == true);
	pila_destruir(pila);
}

void prueba_muchos_elementos(){
	
	printf("\n***INICIO DE PRUEBAS APILANDO UNA CANTIDAD GRANDE DE ELEMENTOS***/\n");
	int* arreglo = malloc(TAM_PRUEBA_ARREGLO*(sizeof(int)));
	pila_t* pila_vector = pila_crear();
	int k,i,j;
	for (k = 0; k < TAM_PRUEBA_ARREGLO; k++){
		arreglo[k] = k;
	}
	for (i = 0; i < TAM_PRUEBA_ARREGLO; i++){
		pila_apilar(pila_vector,(void*)arreglo[i]);
	}
	void* tope_pila = pila_ver_tope(pila_vector);
	print_test("Al ver el tope, se almaceno el ultimo elemento del arreglo",tope_pila == (void*)arreglo[TAM_PRUEBA_ARREGLO-1]);
	int contador_error = 0;
	for (j = TAM_PRUEBA_ARREGLO-1; j>=0; j--){
		void* elemento_desapilado = NULL;
		elemento_desapilado = pila_desapilar(pila_vector);
		if (!(elemento_desapilado == (void*)arreglo[j])){
			contador_error++;
		}
	}
	print_test("Al apilar todos los elementos, desapilo y son los correctos",contador_error ==0);
	bool pila_vacia = pila_esta_vacia(pila_vector);
	print_test("La pila esta vacia al desapilar todos sus elementos",pila_vacia == true);
	pila_destruir(pila_vector);
	free(arreglo);
}
